import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { PublicPortal } from './components/PublicPortal';
import { Toast } from './components/common/Toast';
import { AdminDashboard } from './components/dashboards/AdminDashboard';
import { HeadDashboard } from './components/dashboards/HeadDashboard';
import { InstructorDashboard } from './components/dashboards/InstructorDashboard';
import { StudentDashboard } from './components/dashboards/StudentDashboard';
import { initAuth } from './auth';

const MainAppContent: React.FC = () => {
  const { currentUser, toastMessage } = useApp();
  const [activeTab, setActiveTab] = useState<string>('overview');

  useEffect(() => {
    const unsubscribe = initAuth();
    return () => unsubscribe();
  }, []);

  // Reset activeTab whenever user role changes
  useEffect(() => {
    setActiveTab('overview');
  }, [currentUser?.role]);

  if (!currentUser) {
    return <PublicPortal />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      <Toast message={toastMessage} />
      <Navbar />

      <div className="flex-1 flex w-full max-w-7xl mx-auto">
        {/* Left Sidebar */}
        <Sidebar role={currentUser.role} activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Main Dashboard Container */}
        <main className="flex-1 p-4 lg:p-8 overflow-y-auto">
          {currentUser.role === 'admin' && <AdminDashboard activeTab={activeTab} />}
          {currentUser.role === 'head' && <HeadDashboard activeTab={activeTab} />}
          {currentUser.role === 'instructor' && <InstructorDashboard activeTab={activeTab} />}
          {currentUser.role === 'student' && <StudentDashboard activeTab={activeTab} />}
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
