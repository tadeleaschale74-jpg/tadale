import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  onSnapshot,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import {
  User,
  Course,
  EvaluationCriteria,
  EvaluationSubmission,
  PublishedForm,
  PublishedPeerForm,
  SystemLog,
  SystemConfig,
} from './types';
import {
  INITIAL_USERS,
  INITIAL_COURSES,
  INITIAL_CRITERIA,
  INITIAL_SUBMISSIONS,
  INITIAL_LOGS,
  INITIAL_CONFIG,
} from './data/initialData';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore (using custom databaseId if configured)
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Collection References
export const USERS_COLLECTION = 'users';
export const COURSES_COLLECTION = 'courses';
export const CRITERIA_COLLECTION = 'criteria';
export const SUBMISSIONS_COLLECTION = 'evaluation_submissions';
export const PUBLISHED_FORMS_COLLECTION = 'published_forms';
export const PUBLISHED_PEER_FORMS_COLLECTION = 'published_peer_forms';
export const LOGS_COLLECTION = 'system_logs';
export const CONFIG_COLLECTION = 'system_config';

/**
 * Seed Firestore with initial data if collections are empty.
 */
export async function seedInitialFirestoreData(): Promise<boolean> {
  try {
    const usersSnapshot = await getDocs(collection(db, USERS_COLLECTION));
    if (!usersSnapshot.empty) {
      console.log('Firestore already contains data. Skipping initial seeding.');
      return false;
    }

    console.log('Seeding initial MAU University data to Firestore...');
    const batch = writeBatch(db);

    // Seed Users
    for (const u of INITIAL_USERS) {
      const userRef = doc(db, USERS_COLLECTION, u.id);
      batch.set(userRef, u);
    }

    // Seed Courses
    for (const c of INITIAL_COURSES) {
      const courseRef = doc(db, COURSES_COLLECTION, c.id);
      batch.set(courseRef, c);
    }

    // Seed Criteria
    for (const crit of INITIAL_CRITERIA) {
      const critRef = doc(db, CRITERIA_COLLECTION, crit.id);
      batch.set(critRef, crit);
    }

    // Seed Submissions
    for (const sub of INITIAL_SUBMISSIONS) {
      const subRef = doc(db, SUBMISSIONS_COLLECTION, sub.id);
      batch.set(subRef, sub);
    }

    // Seed Logs
    for (const log of INITIAL_LOGS) {
      const logRef = doc(db, LOGS_COLLECTION, log.id);
      batch.set(logRef, log);
    }

    // Seed Config
    const configRef = doc(db, CONFIG_COLLECTION, 'global_config');
    batch.set(configRef, INITIAL_CONFIG);

    await batch.commit();
    console.log('Successfully seeded initial Firestore dataset!');
    return true;
  } catch (error) {
    console.error('Error seeding initial Firestore data:', error);
    return false;
  }
}

/**
 * Fetch a single user from Firestore by username or email for real-time login.
 */
export async function fetchUserFromDbByCredentials(
  identifier: string
): Promise<User | null> {
  try {
    const trimmed = identifier.trim().toLowerCase();
    const usersRef = collection(db, USERS_COLLECTION);

    // 1. Check by username query
    const qUsername = query(usersRef, where('username', '==', trimmed));
    const querySnapshotUsername = await getDocs(qUsername);
    if (!querySnapshotUsername.empty) {
      const docData = querySnapshotUsername.docs[0].data() as User;
      return docData;
    }

    // 2. Check by email query
    const qEmail = query(usersRef, where('email', '==', trimmed));
    const querySnapshotEmail = await getDocs(qEmail);
    if (!querySnapshotEmail.empty) {
      const docData = querySnapshotEmail.docs[0].data() as User;
      return docData;
    }

    // 3. Fallback: Check case-insensitive match across all docs in collection
    const allUsersSnapshot = await getDocs(usersRef);
    for (const d of allUsersSnapshot.docs) {
      const u = d.data() as User;
      if (
        u.username?.toLowerCase() === trimmed ||
        u.email?.toLowerCase() === trimmed
      ) {
        return u;
      }
    }

    return null;
  } catch (error) {
    console.error('Failed to query user from Firestore:', error);
    return null;
  }
}

/**
 * Fetch all users from Firestore
 */
export async function fetchAllUsersFromDb(): Promise<User[]> {
  try {
    const snap = await getDocs(collection(db, USERS_COLLECTION));
    if (snap.empty) return [];
    return snap.docs.map((d) => d.data() as User);
  } catch (error) {
    console.error('Error fetching users from DB:', error);
    return [];
  }
}

/**
 * Save or update user document in Firestore
 */
export async function saveUserToDb(user: User): Promise<void> {
  try {
    const userRef = doc(db, USERS_COLLECTION, user.id);
    await setDoc(userRef, user, { merge: true });
  } catch (error) {
    console.error('Error saving user to DB:', error);
  }
}

/**
 * Delete user from Firestore
 */
export async function deleteUserFromDb(userId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, USERS_COLLECTION, userId));
  } catch (error) {
    console.error('Error deleting user from DB:', error);
  }
}

/**
 * Fetch all courses from Firestore
 */
export async function fetchAllCoursesFromDb(): Promise<Course[]> {
  try {
    const snap = await getDocs(collection(db, COURSES_COLLECTION));
    if (snap.empty) return [];
    return snap.docs.map((d) => d.data() as Course);
  } catch (error) {
    console.error('Error fetching courses from DB:', error);
    return [];
  }
}

/**
 * Save course to Firestore
 */
export async function saveCourseToDb(course: Course): Promise<void> {
  try {
    const courseRef = doc(db, COURSES_COLLECTION, course.id);
    await setDoc(courseRef, course, { merge: true });
  } catch (error) {
    console.error('Error saving course to DB:', error);
  }
}

/**
 * Fetch all criteria from Firestore
 */
export async function fetchAllCriteriaFromDb(): Promise<EvaluationCriteria[]> {
  try {
    const snap = await getDocs(collection(db, CRITERIA_COLLECTION));
    if (snap.empty) return [];
    return snap.docs.map((d) => d.data() as EvaluationCriteria);
  } catch (error) {
    console.error('Error fetching criteria from DB:', error);
    return [];
  }
}

/**
 * Save criteria item to Firestore
 */
export async function saveCriteriaToDb(criteria: EvaluationCriteria): Promise<void> {
  try {
    const critRef = doc(db, CRITERIA_COLLECTION, criteria.id);
    await setDoc(critRef, criteria, { merge: true });
  } catch (error) {
    console.error('Error saving criteria to DB:', error);
  }
}

/**
 * Fetch all submissions from Firestore
 */
export async function fetchAllSubmissionsFromDb(): Promise<EvaluationSubmission[]> {
  try {
    const snap = await getDocs(collection(db, SUBMISSIONS_COLLECTION));
    if (snap.empty) return [];
    return snap.docs.map((d) => d.data() as EvaluationSubmission);
  } catch (error) {
    console.error('Error fetching submissions from DB:', error);
    return [];
  }
}

/**
 * Save evaluation submission to Firestore
 */
export async function saveSubmissionToDb(submission: EvaluationSubmission): Promise<void> {
  try {
    const subRef = doc(db, SUBMISSIONS_COLLECTION, submission.id);
    await setDoc(subRef, submission, { merge: true });
  } catch (error) {
    console.error('Error saving submission to DB:', error);
  }
}

/**
 * Fetch published forms from Firestore
 */
export async function fetchAllPublishedFormsFromDb(): Promise<PublishedForm[]> {
  try {
    const snap = await getDocs(collection(db, PUBLISHED_FORMS_COLLECTION));
    if (snap.empty) return [];
    return snap.docs.map((d) => d.data() as PublishedForm);
  } catch (error) {
    console.error('Error fetching published forms from DB:', error);
    return [];
  }
}

/**
 * Save published form to Firestore
 */
export async function savePublishedFormToDb(form: PublishedForm): Promise<void> {
  try {
    const ref = doc(db, PUBLISHED_FORMS_COLLECTION, form.id);
    await setDoc(ref, form, { merge: true });
  } catch (error) {
    console.error('Error saving published form to DB:', error);
  }
}

/**
 * Fetch published peer forms from Firestore
 */
export async function fetchAllPublishedPeerFormsFromDb(): Promise<PublishedPeerForm[]> {
  try {
    const snap = await getDocs(collection(db, PUBLISHED_PEER_FORMS_COLLECTION));
    if (snap.empty) return [];
    return snap.docs.map((d) => d.data() as PublishedPeerForm);
  } catch (error) {
    console.error('Error fetching published peer forms from DB:', error);
    return [];
  }
}

/**
 * Save published peer form to Firestore
 */
export async function savePublishedPeerFormToDb(form: PublishedPeerForm): Promise<void> {
  try {
    const ref = doc(db, PUBLISHED_PEER_FORMS_COLLECTION, form.id);
    await setDoc(ref, form, { merge: true });
  } catch (error) {
    console.error('Error saving published peer form to DB:', error);
  }
}

/**
 * Fetch system logs from Firestore
 */
export async function fetchAllLogsFromDb(): Promise<SystemLog[]> {
  try {
    const snap = await getDocs(collection(db, LOGS_COLLECTION));
    if (snap.empty) return [];
    return snap.docs.map((d) => d.data() as SystemLog);
  } catch (error) {
    console.error('Error fetching logs from DB:', error);
    return [];
  }
}

/**
 * Save system log to Firestore
 */
export async function saveLogToDb(log: SystemLog): Promise<void> {
  try {
    const ref = doc(db, LOGS_COLLECTION, log.id);
    await setDoc(ref, log, { merge: true });
  } catch (error) {
    console.error('Error saving log to DB:', error);
  }
}

/**
 * Clear all system logs in Firestore
 */
export async function clearAllLogsInDb(): Promise<void> {
  try {
    const snap = await getDocs(collection(db, LOGS_COLLECTION));
    const batch = writeBatch(db);
    snap.docs.forEach((d) => batch.delete(d.ref));
    await batch.commit();
  } catch (error) {
    console.error('Error clearing logs in DB:', error);
  }
}

/**
 * Fetch system config from Firestore
 */
export async function fetchSystemConfigFromDb(): Promise<SystemConfig | null> {
  try {
    const ref = doc(db, CONFIG_COLLECTION, 'global_config');
    const snap = await getDoc(ref);
    if (snap.exists()) {
      return snap.data() as SystemConfig;
    }
    return null;
  } catch (error) {
    console.error('Error fetching config from DB:', error);
    return null;
  }
}

/**
 * Save system config to Firestore
 */
export async function saveSystemConfigToDb(config: SystemConfig): Promise<void> {
  try {
    const ref = doc(db, CONFIG_COLLECTION, 'global_config');
    await setDoc(ref, config, { merge: true });
  } catch (error) {
    console.error('Error saving config to DB:', error);
  }
}
