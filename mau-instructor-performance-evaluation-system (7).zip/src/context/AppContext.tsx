import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  collection,
  doc,
  onSnapshot,
} from 'firebase/firestore';
import {
  db,
  USERS_COLLECTION,
  COURSES_COLLECTION,
  CRITERIA_COLLECTION,
  SUBMISSIONS_COLLECTION,
  PUBLISHED_FORMS_COLLECTION,
  PUBLISHED_PEER_FORMS_COLLECTION,
  LOGS_COLLECTION,
  CONFIG_COLLECTION,
  seedInitialFirestoreData,
  fetchUserFromDbByCredentials,
  saveUserToDb,
  deleteUserFromDb,
  saveCourseToDb,
  saveSubmissionToDb,
  savePublishedFormToDb,
  savePublishedPeerFormToDb,
  saveLogToDb,
  clearAllLogsInDb,
  saveSystemConfigToDb,
} from '../firebase';
import {
  User,
  UserRole,
  Course,
  EvaluationCriteria,
  EvaluationSubmission,
  SystemLog,
  SystemConfig,
  InstructorFinalScore,
  PublishedForm,
  PublishedPeerForm,
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_COURSES,
  INITIAL_CRITERIA,
  INITIAL_SUBMISSIONS,
  INITIAL_LOGS,
  INITIAL_CONFIG,
} from '../data/initialData';

interface AppContextType {
  currentUser: User | null;
  users: User[];
  courses: Course[];
  criteria: EvaluationCriteria[];
  submissions: EvaluationSubmission[];
  publishedForms: PublishedForm[];
  publishedPeerForms: PublishedPeerForm[];
  logs: SystemLog[];
  systemConfig: SystemConfig;
  toastMessage: { text: string; type: 'success' | 'error' | 'info' } | null;
  dbConnected: boolean;
  isDbLoading: boolean;
  
  // Auth methods
  login: (usernameOrEmail: string, pass: string, role?: UserRole) => Promise<{ success: boolean; message: string; user?: User }>;
  loginAsDemoRole: (role: UserRole, specificUserId?: string) => Promise<void>;
  logout: () => void;
  showToast: (text: string, type?: 'success' | 'error' | 'info') => void;
  syncDbData: () => Promise<void>;

  // Admin Actions
  registerUser: (userData: Omit<User, 'id' | 'createdAt' | 'lastSeen' | 'status'>) => Promise<void>;
  toggleUserLock: (userId: string) => Promise<void>;
  deleteUser: (userId: string) => Promise<void>;
  resetUserPassword: (userId: string, newPass: string) => Promise<void>;
  updateSystemConfig: (newConfig: Partial<SystemConfig>) => Promise<void>;
  clearSystemLogs: () => Promise<void>;

  // Head Actions
  assignCourseInstructor: (courseId: string, instructorId: string | null) => Promise<void>;
  addCourse: (courseData: Omit<Course, 'id'>) => Promise<void>;
  publishEvaluationForm: (formData: Omit<PublishedForm, 'id' | 'publishedAt'>) => Promise<void>;
  publishPeerEvaluationForm: (formData: Omit<PublishedPeerForm, 'id' | 'publishedAt'>) => Promise<void>;

  // Evaluation Actions
  submitEvaluation: (data: Omit<EvaluationSubmission, 'id' | 'submittedAt'>) => Promise<void>;

  // Analytics helper
  getInstructorFinalScore: (instructorId: string) => InstructorFinalScore;
  getAllInstructorsScoresByDepartment: (department?: string) => InstructorFinalScore[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CURRENT_USER: 'mau_current_user',
  USERS: 'mau_users_v1',
  COURSES: 'mau_courses_v1',
  CRITERIA: 'mau_criteria_v1',
  SUBMISSIONS: 'mau_submissions_v1',
  PUBLISHED_FORMS: 'mau_published_forms_v1',
  PUBLISHED_PEER_FORMS: 'mau_published_peer_forms_v1',
  LOGS: 'mau_logs_v1',
  CONFIG: 'mau_config_v1',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize state with localStorage or initial mock data as immediate fallback
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USERS);
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return saved ? JSON.parse(saved) : null;
  });

  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COURSES);
    return saved ? JSON.parse(saved) : INITIAL_COURSES;
  });

  const [criteria, setCriteria] = useState<EvaluationCriteria[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CRITERIA);
    return saved ? JSON.parse(saved) : INITIAL_CRITERIA;
  });

  const [submissions, setSubmissions] = useState<EvaluationSubmission[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SUBMISSIONS);
    return saved ? JSON.parse(saved) : INITIAL_SUBMISSIONS;
  });

  const [publishedForms, setPublishedForms] = useState<PublishedForm[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PUBLISHED_FORMS);
    return saved ? JSON.parse(saved) : [];
  });

  const [publishedPeerForms, setPublishedPeerForms] = useState<PublishedPeerForm[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PUBLISHED_PEER_FORMS);
    return saved ? JSON.parse(saved) : [];
  });

  const [logs, setLogs] = useState<SystemLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LOGS);
    return saved ? JSON.parse(saved) : INITIAL_LOGS;
  });

  const [systemConfig, setSystemConfig] = useState<SystemConfig>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
    return saved ? JSON.parse(saved) : INITIAL_CONFIG;
  });

  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [dbConnected, setDbConnected] = useState<boolean>(true);
  const [isDbLoading, setIsDbLoading] = useState<boolean>(true);

  // Sync state to localStorage for offline resilience
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CRITERIA, JSON.stringify(criteria));
  }, [criteria]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SUBMISSIONS, JSON.stringify(submissions));
  }, [submissions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PUBLISHED_FORMS, JSON.stringify(publishedForms));
  }, [publishedForms]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PUBLISHED_PEER_FORMS, JSON.stringify(publishedPeerForms));
  }, [publishedPeerForms]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(systemConfig));
  }, [systemConfig]);

  // Firestore Real-Time Subscriptions & Initial Seeding
  useEffect(() => {
    let unsubscribeUsers: (() => void) | undefined;
    let unsubscribeCourses: (() => void) | undefined;
    let unsubscribeCriteria: (() => void) | undefined;
    let unsubscribeSubmissions: (() => void) | undefined;
    let unsubscribePublishedForms: (() => void) | undefined;
    let unsubscribePublishedPeerForms: (() => void) | undefined;
    let unsubscribeLogs: (() => void) | undefined;
    let unsubscribeConfig: (() => void) | undefined;

    const setupDatabaseSync = async () => {
      try {
        setIsDbLoading(true);
        // Seed default initial data if Firestore is fresh
        await seedInitialFirestoreData();

        // 1. Listen to Users Collection
        unsubscribeUsers = onSnapshot(
          collection(db, USERS_COLLECTION),
          (snapshot) => {
            if (!snapshot.empty) {
              const dbUsers = snapshot.docs.map((docSnap) => docSnap.data() as User);
              setUsers(dbUsers);
              setDbConnected(true);

              // Update current user if matching in DB
              if (currentUser) {
                const refreshed = dbUsers.find((u) => u.id === currentUser.id);
                if (refreshed) {
                  setCurrentUser(refreshed);
                }
              }
            }
          },
          (err) => {
            console.error('Firestore Users listener error:', err);
            setDbConnected(false);
          }
        );

        // 2. Listen to Courses Collection
        unsubscribeCourses = onSnapshot(
          collection(db, COURSES_COLLECTION),
          (snapshot) => {
            if (!snapshot.empty) {
              const dbCourses = snapshot.docs.map((docSnap) => docSnap.data() as Course);
              setCourses(dbCourses);
            }
          },
          (err) => console.error('Firestore Courses listener error:', err)
        );

        // 3. Listen to Criteria Collection
        unsubscribeCriteria = onSnapshot(
          collection(db, CRITERIA_COLLECTION),
          (snapshot) => {
            if (!snapshot.empty) {
              const dbCriteria = snapshot.docs.map((docSnap) => docSnap.data() as EvaluationCriteria);
              setCriteria(dbCriteria);
            }
          },
          (err) => console.error('Firestore Criteria listener error:', err)
        );

        // 4. Listen to Evaluation Submissions Collection
        unsubscribeSubmissions = onSnapshot(
          collection(db, SUBMISSIONS_COLLECTION),
          (snapshot) => {
            if (!snapshot.empty) {
              const dbSubs = snapshot.docs.map((docSnap) => docSnap.data() as EvaluationSubmission);
              setSubmissions(dbSubs);
            }
          },
          (err) => console.error('Firestore Submissions listener error:', err)
        );

        // 5. Listen to Published Forms Collection
        unsubscribePublishedForms = onSnapshot(
          collection(db, PUBLISHED_FORMS_COLLECTION),
          (snapshot) => {
            const dbForms = snapshot.docs.map((docSnap) => docSnap.data() as PublishedForm);
            setPublishedForms(dbForms);
          },
          (err) => console.error('Firestore Published Forms listener error:', err)
        );

        // 6. Listen to Published Peer Forms Collection
        unsubscribePublishedPeerForms = onSnapshot(
          collection(db, PUBLISHED_PEER_FORMS_COLLECTION),
          (snapshot) => {
            const dbPeerForms = snapshot.docs.map((docSnap) => docSnap.data() as PublishedPeerForm);
            setPublishedPeerForms(dbPeerForms);
          },
          (err) => console.error('Firestore Published Peer Forms listener error:', err)
        );

        // 7. Listen to System Logs Collection
        unsubscribeLogs = onSnapshot(
          collection(db, LOGS_COLLECTION),
          (snapshot) => {
            if (!snapshot.empty) {
              const dbLogs = snapshot.docs.map((docSnap) => docSnap.data() as SystemLog);
              dbLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
              setLogs(dbLogs);
            }
          },
          (err) => console.error('Firestore Logs listener error:', err)
        );

        // 8. Listen to System Config
        unsubscribeConfig = onSnapshot(
          doc(db, CONFIG_COLLECTION, 'global_config'),
          (docSnap) => {
            if (docSnap.exists()) {
              setSystemConfig(docSnap.data() as SystemConfig);
            }
          },
          (err) => console.error('Firestore Config listener error:', err)
        );

        setIsDbLoading(false);
      } catch (err) {
        console.error('Error establishing Firestore connection:', err);
        setDbConnected(false);
        setIsDbLoading(false);
      }
    };

    setupDatabaseSync();

    return () => {
      if (unsubscribeUsers) unsubscribeUsers();
      if (unsubscribeCourses) unsubscribeCourses();
      if (unsubscribeCriteria) unsubscribeCriteria();
      if (unsubscribeSubmissions) unsubscribeSubmissions();
      if (unsubscribePublishedForms) unsubscribePublishedForms();
      if (unsubscribePublishedPeerForms) unsubscribePublishedPeerForms();
      if (unsubscribeLogs) unsubscribeLogs();
      if (unsubscribeConfig) unsubscribeConfig();
    };
  }, []);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const addLog = async (
    action: string,
    details: string,
    userOverride?: { id: string; name: string; role: UserRole },
    status: 'success' | 'warning' | 'error' = 'success'
  ) => {
    const actor = userOverride || (currentUser ? { id: currentUser.id, name: currentUser.fullName, role: currentUser.role } : { id: 'system', name: 'System', role: 'admin' as UserRole });
    const newLog: SystemLog = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action,
      details,
      ipAddress: '197.156.102.' + Math.floor(Math.random() * 200 + 10),
      status,
    };
    setLogs((prev) => [newLog, ...prev]);
    await saveLogToDb(newLog);
  };

  const syncDbData = async () => {
    try {
      showToast('Syncing latest university data with Firestore Database...', 'info');
      await seedInitialFirestoreData();
      showToast('Database synchronization complete!', 'success');
    } catch (err) {
      showToast('Database synchronization error', 'error');
    }
  };

  // Login handler: DIRECT FETCH FROM FIRESTORE DATABASE
  const login = async (usernameOrEmail: string, pass: string, role?: UserRole) => {
    const trimmedInput = usernameOrEmail.trim().toLowerCase();

    // 1. Fetch user directly from Firestore Database
    let foundUser: User | null = await fetchUserFromDbByCredentials(trimmedInput);

    // 2. Fallback to cached memory users if offline or network latency
    if (!foundUser) {
      foundUser = users.find(
        (u) =>
          (u.username.toLowerCase() === trimmedInput ||
           u.email.toLowerCase() === trimmedInput)
      ) || null;
    }

    if (!foundUser) {
      return { success: false, message: `No user account found matching credentials '${usernameOrEmail}'.` };
    }

    // Role check if provided
    if (role && foundUser.role !== role) {
      return { success: false, message: `Account '${foundUser.username}' is assigned to role '${foundUser.role.toUpperCase()}', not '${role.toUpperCase()}'. Please select the matching role.` };
    }

    // Password validation
    if (foundUser.password && foundUser.password !== pass) {
      return { success: false, message: 'Invalid password. Please verify your credentials.' };
    }

    // Account status check
    if (foundUser.status === 'locked') {
      await addLog('LOGIN_BLOCKED', `Blocked login attempt for locked account ${foundUser.username}`, { id: foundUser.id, name: foundUser.fullName, role: foundUser.role }, 'error');
      return { success: false, message: 'This account has been locked by System Administrator. Please contact MAU Quality Assurance Office.' };
    }

    // Update lastSeen in Firestore
    const updatedUser: User = { ...foundUser, lastSeen: new Date().toISOString() };
    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === foundUser!.id ? updatedUser : u)));

    await saveUserToDb(updatedUser);
    await addLog('USER_LOGIN', `User ${foundUser.fullName} (${foundUser.role.toUpperCase()}) authenticated from Firestore Database.`, { id: foundUser.id, name: foundUser.fullName, role: foundUser.role });
    showToast(`Welcome back, ${foundUser.fullName}! (${foundUser.role.toUpperCase()} Portal - DB Connected)`);

    return { success: true, message: 'Login successful', user: updatedUser };
  };

  // Demo Login Quick Switcher
  const loginAsDemoRole = async (role: UserRole, specificUserId?: string) => {
    let target = specificUserId ? users.find((u) => u.id === specificUserId) : users.find((u) => u.role === role && u.status === 'active');
    if (!target) {
      target = users.find((u) => u.role === role);
    }
    if (target) {
      if (target.status === 'locked') {
        showToast(`Account for ${target.fullName} is currently LOCKED by admin.`, 'error');
        return;
      }
      const updatedUser: User = { ...target, lastSeen: new Date().toISOString() };
      setCurrentUser(updatedUser);
      setUsers((prev) => prev.map((u) => (u.id === target!.id ? updatedUser : u)));
      await saveUserToDb(updatedUser);
      await addLog('DEMO_LOGIN', `Switched session to ${target.fullName} (${target.role.toUpperCase()}) via Firestore DB`, { id: target.id, name: target.fullName, role: target.role });
      showToast(`Switched to ${target.fullName} (${target.role.toUpperCase()} Portal)`);
    }
  };

  const logout = async () => {
    if (currentUser) {
      await addLog('USER_LOGOUT', `User ${currentUser.fullName} logged out.`);
    }
    setCurrentUser(null);
    showToast('Logged out successfully.', 'info');
  };

  // Register User (Admin Action) - Persists to Firestore Database
  const registerUser = async (userData: Omit<User, 'id' | 'createdAt' | 'lastSeen' | 'status'>) => {
    const existing = users.find(
      (u) => u.username.toLowerCase() === userData.username.toLowerCase() || u.email.toLowerCase() === userData.email.toLowerCase()
    );
    if (existing) {
      showToast(`Username or email '${userData.username}' already exists in database.`, 'error');
      return;
    }

    const newUser: User = {
      ...userData,
      id: `user_${Date.now()}`,
      status: 'active',
      lastSeen: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    setUsers((prev) => [newUser, ...prev]);
    await saveUserToDb(newUser);
    await addLog('USER_REGISTERED', `Registered new ${userData.role.toUpperCase()} ${userData.fullName} to Firestore Database.`);
    showToast(`Successfully saved ${userData.fullName} to Firestore DB as ${userData.role.toUpperCase()}`);
  };

  // Lock / Unlock user account
  const toggleUserLock = async (userId: string) => {
    const target = users.find((u) => u.id === userId);
    if (target) {
      const newStatus = target.status === 'active' ? 'locked' : 'active';
      const updated: User = { ...target, status: newStatus };
      setUsers((prev) => prev.map((u) => (u.id === userId ? updated : u)));
      await saveUserToDb(updated);
      await addLog(
        newStatus === 'locked' ? 'ACCOUNT_LOCKED' : 'ACCOUNT_UNLOCKED',
        `User account for ${target.fullName} (${target.role}) was ${newStatus.toUpperCase()} in Firestore.`
      );
      showToast(`Account for ${target.fullName} is now ${newStatus.toUpperCase()}`, newStatus === 'locked' ? 'error' : 'success');
    }
  };

  const deleteUser = async (userId: string) => {
    const target = users.find((u) => u.id === userId);
    if (target) {
      setUsers((prev) => prev.filter((u) => u.id !== userId));
      await deleteUserFromDb(userId);
      await addLog('USER_DELETED', `Deleted user account ${target.fullName} (${target.username}) from Firestore DB.`, undefined, 'warning');
      showToast(`Deleted user ${target.fullName} from database`, 'info');
    }
  };

  const resetUserPassword = async (userId: string, newPass: string) => {
    const target = users.find((u) => u.id === userId);
    if (target) {
      const updated: User = { ...target, password: newPass };
      setUsers((prev) => prev.map((u) => (u.id === userId ? updated : u)));
      await saveUserToDb(updated);
      await addLog('PASSWORD_RESET', `Password reset in DB for user ${target.fullName}.`);
      showToast(`Password updated in database for ${target.fullName}`);
    }
  };

  // Update System Config
  const updateSystemConfig = async (newConfig: Partial<SystemConfig>) => {
    const updated = { ...systemConfig, ...newConfig };
    setSystemConfig(updated);
    await saveSystemConfigToDb(updated);
    await addLog('CONFIG_UPDATED', `System configuration updated in Firestore (Evaluation status: ${updated.evaluationOpen ? 'Open' : 'Closed'}).`);
    showToast('System configuration saved to Firestore database!');
  };

  const clearSystemLogs = async () => {
    setLogs([]);
    await clearAllLogsInDb();
    showToast('System logs cleared from Firestore DB', 'info');
  };

  // Course Assignment (Head Action)
  const assignCourseInstructor = async (courseId: string, instructorId: string | null) => {
    const target = courses.find((c) => c.id === courseId);
    if (target) {
      const updated: Course = { ...target, instructorId };
      setCourses((prev) => prev.map((c) => (c.id === courseId ? updated : c)));
      await saveCourseToDb(updated);

      const instructorObj = users.find((u) => u.id === instructorId);
      const instName = instructorObj ? instructorObj.fullName : 'Unassigned';
      await addLog('COURSE_ASSIGNMENT', `Course ${target.code} assigned to ${instName} in DB.`);
      showToast(`Course ${target.code} assigned to ${instName}`);
    }
  };

  const addCourse = async (courseData: Omit<Course, 'id'>) => {
    const newCourse: Course = {
      ...courseData,
      id: `crs_${Date.now()}`,
    };
    setCourses((prev) => [...prev, newCourse]);
    await saveCourseToDb(newCourse);
    await addLog('COURSE_CREATED', `Added new course ${newCourse.code} - ${newCourse.title} to Firestore.`);
    showToast(`Added course ${newCourse.code} to DB`);
  };

  const publishEvaluationForm = async (formData: Omit<PublishedForm, 'id' | 'publishedAt'>) => {
    const newForm: PublishedForm = {
      ...formData,
      id: `pub_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      publishedAt: new Date().toISOString(),
    };
    setPublishedForms((prev) => [newForm, ...prev]);
    await savePublishedFormToDb(newForm);
    await addLog(
      'FORM_PUBLISHED',
      `Student evaluation form published for ${formData.instructorName} (${formData.courseCode}) to ${formData.targetStudentCount} students in ${formData.department}.`
    );
    showToast(
      `Evaluation form published to Firestore DB for ${formData.instructorName}!`,
      'success'
    );
  };

  const publishPeerEvaluationForm = async (formData: Omit<PublishedPeerForm, 'id' | 'publishedAt'>) => {
    const newForm: PublishedPeerForm = {
      ...formData,
      id: `peerpub_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      publishedAt: new Date().toISOString(),
    };
    setPublishedPeerForms((prev) => [newForm, ...prev]);
    await savePublishedPeerFormToDb(newForm);
    await addLog(
      'PEER_FORM_PUBLISHED',
      `Peer evaluation form published for ${formData.targetInstructorName} to ${formData.targetPeerCount} peers in ${formData.department}.`
    );
    showToast(
      `Peer evaluation form dispatched to DB for ${formData.targetInstructorName}!`,
      'success'
    );
  };

  // Submit Evaluation Form (Student, Peer, Head) - Saves to Firestore Database
  const submitEvaluation = async (data: Omit<EvaluationSubmission, 'id' | 'submittedAt'>) => {
    const newSubmission: EvaluationSubmission = {
      ...data,
      id: `sub_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      submittedAt: new Date().toISOString(),
    };

    setSubmissions((prev) => [newSubmission, ...prev]);
    await saveSubmissionToDb(newSubmission);
    await addLog(
      'SUBMIT_EVALUATION',
      `${data.evaluatorRole.toUpperCase()} evaluation submitted by ${data.evaluatorName} for instructor ${data.instructorName} to Firestore DB.`
    );
    showToast(`Evaluation saved to Firestore DB for ${data.instructorName}! (${data.averagePercentage}% score)`);
  };

  // Score Calculation helper (100% calculation formula: 50% Student + 20% Peer + 30% Head)
  const getInstructorFinalScore = (instructorId: string): InstructorFinalScore => {
    const instructor = users.find((u) => u.id === instructorId);
    const instName = instructor ? instructor.fullName : 'Unknown Instructor';
    const dept = instructor ? instructor.department : '';

    const instSubs = submissions.filter((s) => s.instructorId === instructorId);

    // Student Submissions (50% max pool)
    const studentSubs = instSubs.filter((s) => s.evaluatorRole === 'student');
    const deptStudents = users.filter((u) => u.role === 'student' && u.department === dept).length;
    const studentTargetCount = deptStudents > 0 ? deptStudents : 50;

    let studentAvgPct = 0;
    if (studentSubs.length > 0) {
      const sum = studentSubs.reduce((acc, curr) => acc + curr.averagePercentage, 0);
      studentAvgPct = sum / studentSubs.length;
    }
    const studentWeightedScore = (studentAvgPct * (systemConfig.studentWeight / 100)); // out of 50

    // Peer Submissions (20% max pool)
    const peerSubs = instSubs.filter((s) => s.evaluatorRole === 'peer');
    const deptPeers = users.filter((u) => u.role === 'instructor' && u.department === dept && u.id !== instructorId).length;
    const peerTargetCount = deptPeers > 0 ? deptPeers : 3;

    let peerAvgPct = 0;
    if (peerSubs.length > 0) {
      const sum = peerSubs.reduce((acc, curr) => acc + curr.averagePercentage, 0);
      peerAvgPct = sum / peerSubs.length;
    }
    const peerWeightedScore = (peerAvgPct * (systemConfig.peerWeight / 100)); // out of 20

    // Head Submission (30% max pool)
    const headSubs = instSubs.filter((s) => s.evaluatorRole === 'head');
    let headAvgPct = 0;
    const headSubmitted = headSubs.length > 0;
    if (headSubmitted) {
      headAvgPct = headSubs[0].averagePercentage;
    }
    const headWeightedScore = (headAvgPct * (systemConfig.headWeight / 100)); // out of 30

    // Total 100% Comprehensive Score
    const totalFinalScore = Math.round((studentWeightedScore + peerWeightedScore + headWeightedScore) * 10) / 10;

    let grade = 'Pending';
    if (totalFinalScore >= 90) grade = 'A+ (Excellent)';
    else if (totalFinalScore >= 80) grade = 'A (Very Good)';
    else if (totalFinalScore >= 70) grade = 'B (Good)';
    else if (totalFinalScore >= 60) grade = 'C (Satisfactory)';
    else if (totalFinalScore > 0) grade = 'D (Unsatisfactory)';

    return {
      instructorId,
      instructorName: instName,
      department: dept,
      studentScore: Math.round(studentWeightedScore * 10) / 10,
      studentPercentage: Math.round(studentAvgPct * 10) / 10,
      studentSubmissionsCount: studentSubs.length,
      studentTargetCount,

      peerScore: Math.round(peerWeightedScore * 10) / 10,
      peerPercentage: Math.round(peerAvgPct * 10) / 10,
      peerSubmissionsCount: peerSubs.length,
      peerTargetCount,

      headScore: Math.round(headWeightedScore * 10) / 10,
      headPercentage: Math.round(headAvgPct * 10) / 10,
      headSubmitted,

      totalFinalScore,
      grade,
    };
  };

  const getAllInstructorsScoresByDepartment = (department?: string) => {
    let instructorsList = users.filter((u) => u.role === 'instructor');
    if (department) {
      instructorsList = instructorsList.filter((u) => u.department === department);
    }
    return instructorsList.map((inst) => getInstructorFinalScore(inst.id));
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        courses,
        criteria,
        submissions,
        publishedForms,
        publishedPeerForms,
        logs,
        systemConfig,
        toastMessage,
        dbConnected,
        isDbLoading,
        login,
        loginAsDemoRole,
        logout,
        showToast,
        syncDbData,
        registerUser,
        toggleUserLock,
        deleteUser,
        resetUserPassword,
        updateSystemConfig,
        clearSystemLogs,
        assignCourseInstructor,
        addCourse,
        publishEvaluationForm,
        publishPeerEvaluationForm,
        submitEvaluation,
        getInstructorFinalScore,
        getAllInstructorsScoresByDepartment,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
