import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import {
  GraduationCap,
  Shield,
  Building2,
  UserCheck2,
  User,
  KeyRound,
  ArrowRight,
  AlertCircle,
  Sparkles,
  Info,
} from 'lucide-react';
import { motion } from 'motion/react';

export const LoginPage: React.FC = () => {
  const { login, dbConnected, isDbLoading, syncDbData } = useApp();
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');
  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const roles: Array<{
    id: UserRole;
    label: string;
    description: string;
    icon: React.ReactNode;
    color: string;
  }> = [
    {
      id: 'student',
      label: 'Student',
      description: 'Evaluate course instructors in your department',
      icon: <GraduationCap className="w-5 h-5 text-amber-400" />,
      color: 'border-amber-500/50 bg-amber-500/10 text-amber-300',
    },
    {
      id: 'instructor',
      label: 'Instructor',
      description: 'View courses, peer evaluate, and check 100% score',
      icon: <UserCheck2 className="w-5 h-5 text-emerald-400" />,
      color: 'border-emerald-500/50 bg-emerald-500/10 text-emerald-300',
    },
    {
      id: 'head',
      label: 'Department Head',
      description: 'Assign courses, evaluate instructors, calculate final 100%',
      icon: <Building2 className="w-5 h-5 text-indigo-400" />,
      color: 'border-indigo-500/50 bg-indigo-500/10 text-indigo-300',
    },
    {
      id: 'admin',
      label: 'System Admin',
      description: 'Register users, configure system, system logs & account locks',
      icon: <Shield className="w-5 h-5 text-purple-400" />,
      color: 'border-purple-500/50 bg-purple-500/10 text-purple-300',
    },
  ];

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setErrorMessage('');
    setUsernameOrEmail('');
    setPassword('');
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!usernameOrEmail.trim() || !password.trim()) {
      setErrorMessage('Please enter both username/email and password.');
      return;
    }

    try {
      setIsAuthenticating(true);
      const result = await login(usernameOrEmail, password, selectedRole);
      if (!result.success) {
        setErrorMessage(result.message);
      }
    } catch (err) {
      setErrorMessage('Authentication error connecting to Firestore database. Please try again.');
    } finally {
      setIsAuthenticating(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between items-center p-4 lg:p-8 relative overflow-hidden">
      {/* Subtle Background Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[400px] h-[400px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Header */}
      <div className="text-center max-w-xl mx-auto pt-6 space-y-3 z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold tracking-wide">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>Mekdela Amba University - Official Portal</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-100">
          Instructor Performance System
        </h1>
        <p className="text-sm text-slate-400">
          Multi-Evaluator Performance Scoring: Student (50%) • Peer (20%) • Department Head (30%)
        </p>
      </div>

      {/* Main Login Box */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-xl bg-slate-900/90 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-2xl backdrop-blur-xl z-10 my-8"
      >
        {/* Role Selector Tabs */}
        <div className="space-y-3 mb-6">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
            Step 1: Select Your User Role
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {roles.map((r) => {
              const isSelected = selectedRole === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => handleRoleSelect(r.id)}
                  className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all ${
                    isSelected
                      ? `${r.color} shadow-lg ring-2 ring-offset-2 ring-offset-slate-900 ring-indigo-500`
                      : 'border-slate-800 bg-slate-950/50 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <div className="mb-1.5">{r.icon}</div>
                  <span className="text-xs font-bold leading-tight">{r.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Database Live Status Banner */}
        <div className="flex items-center justify-between p-2.5 px-3 bg-slate-950/90 border border-slate-800 rounded-2xl mb-4 text-xs">
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${dbConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <span className="text-slate-300 font-semibold">
              Firestore DB: <span className="text-emerald-400 font-bold">{dbConnected ? 'Connected (Live Cloud)' : 'Connecting...'}</span>
            </span>
          </div>
          <button
            type="button"
            onClick={syncDbData}
            title="Sync / Seed Initial University Dataset to Firestore"
            className="text-[11px] font-bold text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 px-2 py-1 rounded-lg cursor-pointer transition-all"
          >
            Sync Database
          </button>
        </div>

        {/* Selected Role Description Banner */}
        <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl mb-6 flex items-center gap-3">
          <Info className="w-4 h-4 text-indigo-400 shrink-0" />
          <p className="text-xs text-slate-300">
            Logging in as <strong className="text-indigo-300 uppercase">{selectedRole}</strong>: {' '}
            {roles.find((r) => r.id === selectedRole)?.description}
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Username or Institutional Email
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={usernameOrEmail}
                onChange={(e) => setUsernameOrEmail(e.target.value)}
                placeholder="e.g. stud_dawit or dawit@mau.edu.et"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Password
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                required
              />
            </div>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 rounded-xl bg-rose-950/80 border border-rose-700/60 text-rose-200 text-xs flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </motion.div>
          )}

          {/* Login Submit Button */}
          <button
            type="submit"
            disabled={isAuthenticating}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 via-blue-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isAuthenticating ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Fetching User from Database...</span>
              </span>
            ) : (
              <>
                <span>Sign In to {selectedRole.toUpperCase()} Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      </motion.div>

      {/* Footer */}
      <footer className="text-center text-xs text-slate-500 z-10 pb-4">
        © {new Date().getFullYear()} Mekdela Amba University (MAU). All rights reserved. Quality Assurance & Evaluation Unit.
      </footer>
    </div>
  );
};
