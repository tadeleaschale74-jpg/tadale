import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import { MAULogo } from './common/MAULogo';
import {
  GraduationCap,
  Shield,
  Building2,
  UserCheck2,
  User,
  KeyRound,
  ArrowRight,
  AlertCircle,
  Sparkles,
  Home as HomeIcon,
  BookOpen,
  Phone,
  Mail,
  MapPin,
  LogIn,
  CheckCircle2,
  Award,
  Users,
  Send,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const PublicPortal: React.FC = () => {
  const { login } = useApp();
  const [activeNav, setActiveNav] = useState<'home' | 'about' | 'contact' | 'login'>('home');
  
  // Login Form State
  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Contact Form State
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactSent, setContactSent] = useState(false);

  const roles: Array<{
    id: UserRole;
    label: string;
    description: string;
    icon: React.ReactNode;
    color: string;
  }> = [
    {
      id: 'student',
      label: 'Student',
      description: 'Evaluate course instructors in your department',
      icon: <GraduationCap className="w-5 h-5 text-amber-400" />,
      color: 'border-amber-500/50 bg-amber-500/10 text-amber-300',
    },
    {
      id: 'instructor',
      label: 'Instructor',
      description: 'View courses, peer evaluate, and check 100% score',
      icon: <UserCheck2 className="w-5 h-5 text-emerald-400" />,
      color: 'border-emerald-500/50 bg-emerald-500/10 text-emerald-300',
    },
    {
      id: 'head',
      label: 'Department Head',
      description: 'Assign courses, evaluate instructors, calculate final 100%',
      icon: <Building2 className="w-5 h-5 text-indigo-400" />,
      color: 'border-indigo-500/50 bg-indigo-500/10 text-indigo-300',
    },
    {
      id: 'admin',
      label: 'System Admin',
      description: 'Register users, configure system, system logs & account locks',
      icon: <Shield className="w-5 h-5 text-purple-400" />,
      color: 'border-purple-500/50 bg-purple-500/10 text-purple-300',
    },
  ];

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!usernameOrEmail.trim() || !password.trim()) {
      setErrorMessage('Please enter both username/email and password.');
      return;
    }

    const result = login(usernameOrEmail, password);
    if (!result.success) {
      setErrorMessage(result.message);
    }
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactEmail || !contactMessage) return;
    setContactSent(true);
    setTimeout(() => {
      setContactName('');
      setContactEmail('');
      setContactMessage('');
      setContactSent(false);
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between relative overflow-hidden">
      {/* Background Ambient Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-indigo-600/10 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[500px] h-[500px] bg-emerald-600/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-50 bg-slate-950/80 border-b border-slate-800/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          {/* Logo & University Title */}
          <div 
            onClick={() => setActiveNav('home')} 
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="p-1 rounded-2xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-emerald-500 flex items-center justify-center text-white shadow-lg shadow-indigo-600/20 group-hover:scale-105 transition-transform bg-slate-900 border border-slate-800">
              <MAULogo size="md" />
            </div>
            <div>
              <div className="text-base font-extrabold tracking-tight text-slate-100 flex items-center gap-2">
                <span>Mekdela Amba University</span>
                <span className="hidden md:inline-block px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[10px] font-bold tracking-wider uppercase border border-indigo-500/30">
                  MAU QA
                </span>
              </div>
              <div className="text-xs text-slate-400 font-medium">
                Instructor Performance Evaluation System
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveNav('home')}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeNav === 'home'
                  ? 'bg-slate-800 text-indigo-300 border border-indigo-500/40 shadow-sm'
                  : 'text-slate-300 hover:text-slate-100 hover:bg-slate-900'
              }`}
            >
              <HomeIcon className="w-4 h-4 text-indigo-400" />
              <span>Home</span>
            </button>

            <button
              onClick={() => setActiveNav('about')}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeNav === 'about'
                  ? 'bg-slate-800 text-indigo-300 border border-indigo-500/40 shadow-sm'
                  : 'text-slate-300 hover:text-slate-100 hover:bg-slate-900'
              }`}
            >
              <BookOpen className="w-4 h-4 text-indigo-400" />
              <span>About Us</span>
            </button>

            <button
              onClick={() => setActiveNav('contact')}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeNav === 'contact'
                  ? 'bg-slate-800 text-indigo-300 border border-indigo-500/40 shadow-sm'
                  : 'text-slate-300 hover:text-slate-100 hover:bg-slate-900'
              }`}
            >
              <Phone className="w-4 h-4 text-indigo-400" />
              <span>Contact</span>
            </button>

            <button
              onClick={() => setActiveNav('login')}
              className={`ml-2 px-4 sm:px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 cursor-pointer ${
                activeNav === 'login'
                  ? 'bg-gradient-to-r from-indigo-600 to-emerald-600 text-white shadow-lg shadow-indigo-600/30 ring-2 ring-indigo-400'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md'
              }`}
            >
              <LogIn className="w-4 h-4" />
              <span>Login</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Dynamic Content Views */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 z-10 flex items-center justify-center">
        <AnimatePresence mode="wait">
          {/* HOME VIEW */}
          {activeNav === 'home' && (
            <motion.div
              key="home_view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="w-full space-y-12 py-6"
            >
              {/* Hero Banner */}
              <div className="text-center max-w-3xl mx-auto space-y-4">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-bold tracking-wide">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Mekdela Amba University • Quality Assurance Directorate</span>
                </div>
                <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-slate-100 leading-tight">
                  Academic Instructor Performance Evaluation System
                </h1>
                <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl mx-auto">
                  An objective, multi-tiered evaluation portal empowering Mekdela Amba University with continuous quality enhancement, transparent scoring, and actionable performance insights across all academic departments.
                </p>
                <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
                  <button
                    onClick={() => setActiveNav('login')}
                    className="px-6 py-3 rounded-2xl bg-gradient-to-r from-indigo-600 via-blue-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 flex items-center gap-2 transition-all cursor-pointer"
                  >
                    <span>Log In to Dashboard</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setActiveNav('about')}
                    className="px-6 py-3 rounded-2xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-200 font-semibold text-sm transition-all cursor-pointer"
                  >
                    <span>Learn About Scoring Model</span>
                  </button>
                </div>
              </div>

              {/* 3-Tier Multi-Evaluator Weight Pool Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-6 rounded-3xl bg-slate-900/90 border border-amber-500/30 shadow-xl space-y-4 relative overflow-hidden group hover:border-amber-500/60 transition-all">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs font-extrabold uppercase tracking-wider text-amber-400">50% Weight Pool</div>
                    <h3 className="text-xl font-bold text-slate-100 mt-1">Student Evaluations</h3>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Course-registered students evaluate instructors on pedagogy, lecture clarity, lab delivery, approachability, and assessment fairness.
                  </p>
                </div>

                <div className="p-6 rounded-3xl bg-slate-900/90 border border-emerald-500/30 shadow-xl space-y-4 relative overflow-hidden group hover:border-emerald-500/60 transition-all">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs font-extrabold uppercase tracking-wider text-emerald-400">20% Weight Pool</div>
                    <h3 className="text-xl font-bold text-slate-100 mt-1">Peer Colleague Review</h3>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Department instructors assess colleague collaboration, research contribution, curriculum sharing, and professional ethics.
                  </p>
                </div>

                <div className="p-6 rounded-3xl bg-slate-900/90 border border-indigo-500/30 shadow-xl space-y-4 relative overflow-hidden group hover:border-indigo-500/60 transition-all">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs font-extrabold uppercase tracking-wider text-indigo-400">30% Weight Pool</div>
                    <h3 className="text-xl font-bold text-slate-100 mt-1">Department Head Audit</h3>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Department Heads conduct comprehensive administrative reviews covering course outline compliance, punctuality, and committee work.
                  </p>
                </div>
              </div>

              {/* Portal Highlights */}
              <div className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="space-y-2 text-center md:text-left">
                  <h3 className="text-lg font-bold text-slate-100 flex items-center justify-center md:justify-start gap-2">
                    <Award className="w-5 h-5 text-indigo-400" />
                    <span>Official Quality Assurance Standard</span>
                  </h3>
                  <p className="text-xs text-slate-400 max-w-xl">
                    Approved under Mekdela Amba University Senate academic regulation guidelines. Real-time audit trails ensure full data integrity and zero unauthorized score tampering.
                  </p>
                </div>
                <button
                  onClick={() => setActiveNav('login')}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-indigo-500/30 font-bold text-xs shrink-0 cursor-pointer"
                >
                  Sign In to Access Dashboard
                </button>
              </div>
            </motion.div>
          )}

          {/* ABOUT US VIEW */}
          {activeNav === 'about' && (
            <motion.div
              key="about_view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="w-full max-w-4xl py-6 space-y-8"
            >
              <div className="p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6 shadow-2xl">
                <div className="border-b border-slate-800 pb-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-300 text-xs font-bold mb-2">
                    <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                    <span>About Mekdela Amba University</span>
                  </div>
                  <h2 className="text-2xl font-extrabold text-slate-100">Quality Assurance & Performance Evaluation Directorate</h2>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Mekdela Amba University (MAU) is a premier public higher education institution committed to academic excellence, innovative research, and community engagement in Ethiopia. The Quality Assurance Directorate oversees academic standards and faculty performance metrics to maintain competitive, world-class higher education standards.
                </p>

                <div className="space-y-4 pt-2">
                  <h3 className="text-sm font-bold text-indigo-300 uppercase tracking-wider">
                    Evaluation Weight Distribution Formula
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                      <div className="text-amber-400 font-black text-2xl">50%</div>
                      <div className="text-xs font-bold text-slate-200">Student Evaluation</div>
                      <div className="text-[11px] text-slate-400">Classroom pedagogy & fairness</div>
                    </div>
                    <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                      <div className="text-emerald-400 font-black text-2xl">20%</div>
                      <div className="text-xs font-bold text-slate-200">Peer Colleague Rating</div>
                      <div className="text-[11px] text-slate-400">Professionalism & teamwork</div>
                    </div>
                    <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                      <div className="text-indigo-400 font-black text-2xl">30%</div>
                      <div className="text-xs font-bold text-slate-200">Department Head Audit</div>
                      <div className="text-[11px] text-slate-400">Compliance & administration</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  <h3 className="text-sm font-bold text-indigo-300 uppercase tracking-wider">
                    Academic Performance Grading Scale
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center text-xs">
                    <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800/60 text-emerald-300">
                      <div className="font-black text-base">≥ 90%</div>
                      <div className="font-bold mt-1">Excellent</div>
                    </div>
                    <div className="p-3 rounded-xl bg-teal-950/60 border border-teal-800/60 text-teal-300">
                      <div className="font-black text-base">80% – 89%</div>
                      <div className="font-bold mt-1">Very Good</div>
                    </div>
                    <div className="p-3 rounded-xl bg-blue-950/60 border border-blue-800/60 text-blue-300">
                      <div className="font-black text-base">70% – 79%</div>
                      <div className="font-bold mt-1">Good</div>
                    </div>
                    <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-800/60 text-amber-300">
                      <div className="font-black text-base">60% – 69%</div>
                      <div className="font-bold mt-1">Satisfactory</div>
                    </div>
                    <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-800/60 text-rose-300">
                      <div className="font-black text-base">&lt; 60%</div>
                      <div className="font-bold mt-1">Unsatisfactory</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* CONTACT VIEW */}
          {activeNav === 'contact' && (
            <motion.div
              key="contact_view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="w-full max-w-4xl py-6 space-y-8"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Contact Info Card */}
                <div className="p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6 shadow-2xl">
                  <div>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-300 text-xs font-bold mb-2">
                      <Phone className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Contact MAU Administration</span>
                    </div>
                    <h2 className="text-2xl font-extrabold text-slate-100">Get in Touch</h2>
                    <p className="text-xs text-slate-400 mt-1">
                      Quality Assurance Directorate & System Support Team
                    </p>
                  </div>

                  <div className="space-y-4 text-xs text-slate-300">
                    <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                      <MapPin className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-slate-100">Location</div>
                        <div className="text-slate-400 mt-0.5">
                          Tulu Awulia Main Campus, Quality Assurance Building, Room 104, Amhara Region, Ethiopia
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                      <Mail className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-slate-100">Institutional Email</div>
                        <div className="text-slate-400 mt-0.5 font-mono">
                          tadeaschu1@gmail.com / tadeleabatihun@mkau.edu.et
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                      <Phone className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-slate-100">Phone Number</div>
                        <div className="text-slate-400 mt-0.5 font-mono">
                          +251 97 421 3404 (+251974213404)
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Send Message Form */}
                <div className="p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-2xl">
                  <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                    <Send className="w-4 h-4 text-indigo-400" />
                    <span>Send Support Inquiry</span>
                  </h3>

                  {contactSent ? (
                    <div className="p-6 rounded-2xl bg-emerald-950/80 border border-emerald-700/60 text-emerald-200 text-xs space-y-2 text-center">
                      <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                      <div className="font-bold text-sm">Inquiry Submitted Successfully</div>
                      <p className="text-slate-300">
                        Thank you! Your message has been sent to the MAU Quality Assurance Directorate.
                      </p>
                    </div>
                  ) : (
                    <form onSubmit={handleContactSubmit} className="space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">Your Full Name</label>
                        <input
                          type="text"
                          value={contactName}
                          onChange={(e) => setContactName(e.target.value)}
                          placeholder="e.g. Abebe Bekele"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">Your Email</label>
                        <input
                          type="email"
                          value={contactEmail}
                          onChange={(e) => setContactEmail(e.target.value)}
                          placeholder="e.g. user@mau.edu.et"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">Message / Inquiry</label>
                        <textarea
                          rows={3}
                          value={contactMessage}
                          onChange={(e) => setContactMessage(e.target.value)}
                          placeholder="Type your inquiry regarding evaluation criteria or account access..."
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                          required
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
                      >
                        <Send className="w-4 h-4" />
                        <span>Submit Inquiry to QA Unit</span>
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* LOGIN VIEW */}
          {activeNav === 'login' && (
            <motion.div
              key="login_view"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
              className="w-full max-w-lg my-6"
            >
              <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-2xl backdrop-blur-xl">
                <div className="text-center mb-6 space-y-3">
                  {/* Official MAU Emblem Logo */}
                  <div className="flex flex-col items-center justify-center gap-2">
                    <div className="p-2 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl shadow-indigo-500/10 inline-flex items-center justify-center">
                      <MAULogo size="xl" />
                    </div>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-[11px] font-bold">
                      <LogIn className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Mekdela Amba University Portal</span>
                    </div>
                  </div>
                  <div>
                    <h2 className="text-xl font-extrabold text-slate-100">Sign In to Your Dashboard</h2>
                    <p className="text-xs text-slate-400 mt-1">Enter your institutional credentials to access your dashboard</p>
                  </div>
                </div>

                {/* Login Form */}
                <form onSubmit={handleFormSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Username or Institutional Email
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={usernameOrEmail}
                        onChange={(e) => setUsernameOrEmail(e.target.value)}
                        placeholder="e.g. stud_dawit or dawit@mau.edu.et"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Password
                    </label>
                    <div className="relative">
                      <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                        required
                      />
                    </div>
                  </div>

                  {/* Error Banner */}
                  {errorMessage && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 rounded-xl bg-rose-950/80 border border-rose-700/60 text-rose-200 text-xs flex items-center gap-2"
                    >
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{errorMessage}</span>
                    </motion.div>
                  )}

                  {/* Login Submit Button */}
                  <button
                    type="submit"
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 via-blue-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <span>Sign In to Dashboard</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/90 py-4 text-center text-xs text-slate-500 z-10">
        © {new Date().getFullYear()} Mekdela Amba University (MAU). All rights reserved. Quality Assurance & Academic Evaluation Unit.
      </footer>
    </div>
  );
};
