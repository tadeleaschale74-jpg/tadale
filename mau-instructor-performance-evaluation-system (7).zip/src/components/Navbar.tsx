import React from 'react';
import { useApp } from '../context/AppContext';
import { MAULogo } from './common/MAULogo';
import {
  LogOut,
  Calendar,
  Clock,
  Database,
} from 'lucide-react';
import { UserRole } from '../types';

export const Navbar: React.FC = () => {
  const { currentUser, logout, systemConfig, dbConnected } = useApp();

  if (!currentUser) return null;

  const roleColors: Record<UserRole, { bg: string; text: string; border: string }> = {
    admin: { bg: 'bg-purple-950/60', text: 'text-purple-300', border: 'border-purple-700/50' },
    head: { bg: 'bg-indigo-950/60', text: 'text-indigo-300', border: 'border-indigo-700/50' },
    instructor: { bg: 'bg-emerald-950/60', text: 'text-emerald-300', border: 'border-emerald-700/50' },
    student: { bg: 'bg-amber-950/60', text: 'text-amber-300', border: 'border-amber-700/50' },
  };

  const roleLabels: Record<UserRole, string> = {
    admin: 'System Admin',
    head: 'Department Head',
    instructor: 'Instructor / Lecturer',
    student: 'Student',
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 border-b border-slate-800 backdrop-blur-md px-4 lg:px-8 py-3 transition-all">
      <div className="flex items-center justify-between gap-4 max-w-7xl mx-auto">
        {/* Brand & Emblem */}
        <div className="flex items-center gap-3">
          <div className="p-1 rounded-xl bg-slate-950 border border-slate-800 shadow-md shrink-0">
            <MAULogo size="md" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-slate-100 text-base lg:text-lg leading-tight tracking-tight">
                Mekdela Amba University
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-semibold tracking-wider uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full">
                MAU-IPES
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium hidden sm:block">
              Instructor Performance Evaluation System ({systemConfig.academicYear})
            </p>
          </div>
        </div>

        {/* Center Stats / Period Badge & Firestore Status */}
        <div className="hidden lg:flex items-center gap-4 bg-slate-950/60 border border-slate-800/80 px-3.5 py-1.5 rounded-full text-xs">
          {/* DB Indicator */}
          <div className="flex items-center gap-1.5 text-slate-300" title="Google Cloud Firestore Live Database">
            <Database className="w-3.5 h-3.5 text-indigo-400" />
            <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
              <span className={`w-1.5 h-1.5 rounded-full ${dbConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              Firestore Live
            </span>
          </div>
          <div className="w-1 h-1 rounded-full bg-slate-700" />
          <div className="flex items-center gap-1.5 text-slate-300">
            <Calendar className="w-3.5 h-3.5 text-indigo-400" />
            <span>{systemConfig.semester}</span>
          </div>
          <div className="w-1 h-1 rounded-full bg-slate-700" />
          <div className="flex items-center gap-1.5 text-slate-300">
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              Deadline: <strong className="text-slate-200">{new Date(systemConfig.expiryDate).toLocaleDateString()}</strong>
            </span>
          </div>
          <div className="w-1 h-1 rounded-full bg-slate-700" />
          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium ${
              systemConfig.evaluationOpen
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
            }`}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${systemConfig.evaluationOpen ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
            {systemConfig.evaluationOpen ? 'Evaluation Open' : 'Evaluation Closed'}
          </span>
        </div>

        {/* Right Actions: User Profile */}
        <div className="flex items-center gap-3">
          {/* Current User Badge */}
          <div
            className={`flex items-center gap-2.5 px-3 py-1.5 rounded-xl border ${
              roleColors[currentUser.role].bg
            } ${roleColors[currentUser.role].border}`}
          >
            <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center font-bold text-xs text-slate-200 uppercase shrink-0">
              {currentUser.fullName.charAt(0)}
            </div>
            <div className="hidden md:block text-left">
              <div className="text-xs font-bold text-slate-100 leading-tight">
                {currentUser.fullName}
              </div>
              <div className="flex items-center gap-1 text-[11px] font-medium text-slate-300">
                <span className={roleColors[currentUser.role].text}>
                  {roleLabels[currentUser.role]}
                </span>
                <span className="text-slate-500">•</span>
                <span className="text-slate-400 truncate max-w-[100px]">{currentUser.department}</span>
              </div>
            </div>
          </div>

          {/* Logout Button */}
          <button
            onClick={logout}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-rose-900/30 text-slate-400 hover:text-rose-300 border border-slate-700 hover:border-rose-700/50 transition-all text-xs font-medium flex items-center gap-1.5"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden xl:inline">Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
};
