import React from 'react';
import logoImg from '../../assets/images/mau_university_logo_1786551336834.jpg';

interface MAULogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const MAULogo: React.FC<MAULogoProps> = ({ className = '', size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
  }[size];

  return (
    <div className={`relative inline-flex items-center justify-center shrink-0 ${sizeClasses} ${className}`}>
      <img
        src={logoImg}
        alt="Mekdela Amba University Logo"
        referrerPolicy="no-referrer"
        className="w-full h-full object-contain filter drop-shadow-md rounded-xl"
      />
    </div>
  );
};
