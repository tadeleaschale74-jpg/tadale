import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  UserPlus,
  Shield,
  Clock,
  History,
  Lock,
  Unlock,
  Settings,
  Search,
  CheckCircle2,
  AlertCircle,
  Trash2,
  KeyRound,
  Calendar,
  Building2,
  GraduationCap,
  UserCheck2,
  Sparkles,
  RefreshCw,
  Sliders,
} from 'lucide-react';
import { UserRole, UserStatus, COLLEGES_AND_DEPARTMENTS } from '../../types';
import { Modal } from '../common/Modal';

interface AdminDashboardProps {
  activeTab: string;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ activeTab }) => {
  const {
    users,
    registerUser,
    toggleUserLock,
    deleteUser,
    resetUserPassword,
    systemConfig,
    updateSystemConfig,
    logs,
    clearSystemLogs,
  } = useApp();

  // Filter & Search states
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [deptFilter, setDeptFilter] = useState<string>('all');

  // New User Registration Form state
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [regRole, setRegRole] = useState<UserRole>('instructor');
  const [regFullName, setRegFullName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regCollege, setRegCollege] = useState('College of Computing & Informatics');
  const [regDepartment, setRegDepartment] = useState('Computer Science');
  const [regYearLevel, setRegYearLevel] = useState('N/A - Faculty');
  const [regSemester, setRegSemester] = useState(systemConfig.semester || 'Semester II');
  const [regAcademicYear, setRegAcademicYear] = useState(systemConfig.academicYear || '2025/2026');
  const [regDate, setRegDate] = useState(new Date().toISOString().split('T')[0]);
  const [regTitle, setRegTitle] = useState('Lecturer');

  const collegesList = Object.keys(COLLEGES_AND_DEPARTMENTS);

  const handleCollegeChange = (selectedCollege: string) => {
    setRegCollege(selectedCollege);
    const depts = COLLEGES_AND_DEPARTMENTS[selectedCollege] || [];
    if (depts.length > 0) {
      setRegDepartment(depts[0]);
    } else {
      setRegDepartment('');
    }
  };

  // Config Form state
  const [configExpiry, setConfigExpiry] = useState(systemConfig.expiryDate);
  const [configOpen, setConfigOpen] = useState(systemConfig.evaluationOpen);
  const [configStudentWeight, setConfigStudentWeight] = useState(systemConfig.studentWeight);
  const [configPeerWeight, setConfigPeerWeight] = useState(systemConfig.peerWeight);
  const [configHeadWeight, setConfigHeadWeight] = useState(systemConfig.headWeight);

  // Password reset modal state
  const [resetModalUserId, setResetModalUserId] = useState<string | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');

  const departments = [
    'Computer Science',
    'Information Technology',
    'Electrical Engineering',
    'Mechanical Engineering',
    'Civil Engineering',
    'Business & Economics',
    'ICT & Quality Assurance',
  ];

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    const matchesDept = deptFilter === 'all' || u.department === deptFilter;
    return matchesSearch && matchesRole && matchesDept;
  });

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regFullName || !regUsername || !regEmail || !regPassword) return;

    registerUser({
      fullName: regFullName,
      username: regUsername,
      email: regEmail,
      password: regPassword,
      role: regRole,
      college: regCollege,
      department: regDepartment,
      yearLevel: regYearLevel,
      semester: regSemester,
      academicYear: regAcademicYear,
      registrationDate: regDate,
      title: regTitle,
    });

    setIsRegisterModalOpen(false);
    setRegFullName('');
    setRegUsername('');
    setRegEmail('');
    setRegPassword('');
  };

  const handleConfigSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (configStudentWeight + configPeerWeight + configHeadWeight !== 100) {
      alert('Total weights must sum up to exactly 100%!');
      return;
    }
    updateSystemConfig({
      expiryDate: configExpiry,
      evaluationOpen: configOpen,
      studentWeight: configStudentWeight,
      peerWeight: configPeerWeight,
      headWeight: configHeadWeight,
    });
  };

  const handlePasswordResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (resetModalUserId && newPasswordInput) {
      resetUserPassword(resetModalUserId, newPasswordInput);
      setResetModalUserId(null);
      setNewPasswordInput('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Top Banner */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-900/60 via-indigo-900/50 to-slate-900 border border-purple-800/50 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-semibold mb-2">
                <Shield className="w-3.5 h-3.5 text-purple-400" />
                <span>MAU Quality Assurance & Admin Control Center</span>
              </div>
              <h2 className="text-xl font-bold text-slate-100">System Administration Overview</h2>
              <p className="text-xs text-slate-300 mt-1">
                Manage registered Heads, Instructors, Students, system locks, evaluation schedules, and audit logs.
              </p>
            </div>
            <button
              onClick={() => setIsRegisterModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 flex items-center gap-2 transition-all shrink-0 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>Register New User</span>
            </button>
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <div className="text-xs font-medium text-slate-400">Total Registered Users</div>
                <div className="text-2xl font-black text-slate-100">{users.length}</div>
                <div className="text-[11px] text-slate-400">
                  {users.filter((u) => u.role === 'student').length} Students, {users.filter((u) => u.role === 'instructor').length} Instructors
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <div className="text-xs font-medium text-slate-400">Department Heads</div>
                <div className="text-2xl font-black text-slate-100">
                  {users.filter((u) => u.role === 'head').length}
                </div>
                <div className="text-[11px] text-slate-400">Across {departments.length} faculties</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <div className="text-xs font-medium text-slate-400">Locked Accounts</div>
                <div className="text-2xl font-black text-slate-100">
                  {users.filter((u) => u.status === 'locked').length}
                </div>
                <div className="text-[11px] text-slate-400">Blocked from system access</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <div className="text-xs font-medium text-slate-400">Evaluation Expiry Date</div>
                <div className="text-sm font-bold text-slate-100">
                  {new Date(systemConfig.expiryDate).toLocaleDateString()}
                </div>
                <div className="text-[11px] text-emerald-400 font-medium">
                  {systemConfig.evaluationOpen ? 'Active Period' : 'Closed'}
                </div>
              </div>
            </div>
          </div>

          {/* User Management Quick Section */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-400" />
                <span>Registered System Users Directory</span>
              </h3>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-64">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search by name, email, role..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <button
                  onClick={() => setIsRegisterModalOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shrink-0"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Register</span>
                </button>
              </div>
            </div>

            {/* User List Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">User Details</th>
                    <th className="px-4 py-3">Role</th>
                    <th className="px-4 py-3">Department</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Last Seen</th>
                    <th className="px-4 py-3 text-right">Lock / Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredUsers.slice(0, 6).map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-4 py-3 font-medium text-slate-100">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center font-bold text-slate-300">
                            {u.fullName.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-slate-100">{u.fullName}</div>
                            <div className="text-[11px] text-slate-400">{u.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-indigo-300 border border-slate-700">
                          {u.role}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-300">{u.department}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            u.status === 'active'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          }`}
                        >
                          {u.status === 'active' ? 'Active' : 'Locked'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-400 text-[11px]">
                        {new Date(u.lastSeen).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => toggleUserLock(u.id)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 transition-all ${
                            u.status === 'active'
                              ? 'bg-rose-950/60 text-rose-300 hover:bg-rose-900/80 border border-rose-800/50'
                              : 'bg-emerald-950/60 text-emerald-300 hover:bg-emerald-900/80 border border-emerald-800/50'
                          }`}
                        >
                          {u.status === 'active' ? (
                            <>
                              <Lock className="w-3 h-3" /> Lock
                            </>
                          ) : (
                            <>
                              <Unlock className="w-3 h-3" /> Unlock
                            </>
                          )}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* User Registration & Full Directory Tab */}
      {activeTab === 'register_users' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-purple-400" />
                <span>User Registration & Role Assignment</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Register new Department Heads, Instructors, and Students for Mekdela Amba University.
              </p>
            </div>
            <button
              onClick={() => setIsRegisterModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 flex items-center gap-2 transition-all shrink-0 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>Register New User</span>
            </button>
          </div>

          {/* Filter Bar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-semibold">Filter Role:</span>
                <select
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 text-xs text-slate-200 rounded-xl px-3 py-1.5 focus:outline-none focus:border-purple-500"
                >
                  <option value="all">All Roles</option>
                  <option value="head">Department Head</option>
                  <option value="instructor">Instructor</option>
                  <option value="student">Student</option>
                  <option value="admin">Admin</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-semibold">Department:</span>
                <select
                  value={deptFilter}
                  onChange={(e) => setDeptFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 text-xs text-slate-200 rounded-xl px-3 py-1.5 focus:outline-none focus:border-purple-500"
                >
                  <option value="all">All Departments</option>
                  {departments.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search user..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Users Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3.5">User Details</th>
                    <th className="px-4 py-3.5">Role</th>
                    <th className="px-4 py-3.5">College & Department</th>
                    <th className="px-4 py-3.5">Academic Session</th>
                    <th className="px-4 py-3.5">Reg. Date</th>
                    <th className="px-4 py-3.5">Account Status</th>
                    <th className="px-4 py-3.5 text-right">Actions & Controls</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-4 py-3.5 font-medium text-slate-100">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-slate-200">
                            {u.fullName.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-slate-100 flex items-center gap-2">
                              <span>{u.fullName}</span>
                              {u.title && (
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-normal">
                                  {u.title}
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-400">@{u.username} • {u.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-purple-300 border border-slate-700">
                          {u.role}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-slate-300">
                        <div className="font-bold text-slate-100">{u.department}</div>
                        <div className="text-[10px] text-slate-400">{u.college || 'College of Computing & Informatics'}</div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-300 text-[11px]">
                        <div className="font-semibold text-slate-200">
                          {u.role === 'student' ? (u.yearLevel || 'Year 1') : (u.yearLevel || 'Faculty / Staff')}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {u.semester || 'Semester II'} • {u.academicYear || '2025/2026'}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-400 text-[11px]">
                        {u.registrationDate || new Date(u.createdAt).toISOString().split('T')[0]}
                      </td>
                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            u.status === 'active'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          }`}
                        >
                          {u.status === 'active' ? 'Active' : 'Locked'}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-right space-x-2">
                        <button
                          onClick={() => toggleUserLock(u.id)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 transition-all ${
                            u.status === 'active'
                              ? 'bg-rose-950/60 text-rose-300 hover:bg-rose-900 border border-rose-800/50'
                              : 'bg-emerald-950/60 text-emerald-300 hover:bg-emerald-900 border border-emerald-800/50'
                          }`}
                          title="Toggle Account Lock/Unlock"
                        >
                          {u.status === 'active' ? (
                            <>
                              <Lock className="w-3 h-3" /> Lock
                            </>
                          ) : (
                            <>
                              <Unlock className="w-3 h-3" /> Unlock
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => {
                            setResetModalUserId(u.id);
                            setNewPasswordInput('');
                          }}
                          className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 inline-flex items-center gap-1"
                          title="Reset Password"
                        >
                          <KeyRound className="w-3 h-3" /> Reset
                        </button>

                        {u.role !== 'admin' && (
                          <button
                            onClick={() => deleteUser(u.id)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400 border border-slate-700 hover:border-rose-800"
                            title="Delete User"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* System Last Seen & Active Monitor Tab */}
      {activeTab === 'last_seen' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <Clock className="w-5 h-5 text-indigo-400" />
                <span>System Last Seen & User Active Status Monitor</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Real-time tracking of last user logins, online timestamps, session status, and lock triggers.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {users.map((u) => {
              const diffMinutes = Math.floor((Date.now() - new Date(u.lastSeen).getTime()) / (1000 * 60));
              const isOnline = diffMinutes < 10;
              return (
                <div
                  key={u.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    u.status === 'locked'
                      ? 'bg-rose-950/20 border-rose-900/40'
                      : 'bg-slate-900 border-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center font-bold text-slate-200">
                        {u.fullName.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-slate-100 text-sm">{u.fullName}</div>
                        <div className="text-xs text-slate-400">@{u.username} • {u.role.toUpperCase()}</div>
                      </div>
                    </div>

                    <span
                      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        u.status === 'locked'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          : isOnline
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          u.status === 'locked'
                            ? 'bg-rose-500'
                            : isOnline
                            ? 'bg-emerald-400 animate-pulse'
                            : 'bg-slate-500'
                        }`}
                      />
                      {u.status === 'locked' ? 'Locked' : isOnline ? 'Online Now' : 'Offline'}
                    </span>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-2 text-xs">
                    <div className="flex justify-between text-slate-400">
                      <span>Department:</span>
                      <span className="font-medium text-slate-200">{u.department}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Last Seen Timestamp:</span>
                      <span className="font-medium text-indigo-300">
                        {new Date(u.lastSeen).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-end">
                    <button
                      onClick={() => toggleUserLock(u.id)}
                      className={`w-full py-1.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 ${
                        u.status === 'active'
                          ? 'bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800/50'
                          : 'bg-emerald-950/60 hover:bg-emerald-900 text-emerald-300 border border-emerald-800/50'
                      }`}
                    >
                      {u.status === 'active' ? (
                        <>
                          <Lock className="w-3.5 h-3.5" /> Lock Account Access
                        </>
                      ) : (
                        <>
                          <Unlock className="w-3.5 h-3.5" /> Unlock Account Access
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* System Configuration Tab */}
      {activeTab === 'system_config' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Settings className="w-5 h-5 text-purple-400" />
              <span>System Configuration & Evaluation Schedule Settings</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Configure evaluation deadlines, weight distributions, and university evaluation policies.
            </p>
          </div>

          <form onSubmit={handleConfigSubmit} className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Expiry Date & Evaluation Toggle */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-emerald-400" />
                  <span>Evaluation Period & Deadline Date</span>
                </h3>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Evaluation Expiry Date & Time Deadline
                  </label>
                  <input
                    type="datetime-local"
                    value={configExpiry}
                    onChange={(e) => setConfigExpiry(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-purple-500"
                    required
                  />
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-xs text-slate-200">Evaluation Portal Status</div>
                    <div className="text-[11px] text-slate-400">Enable or disable evaluation submissions</div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={configOpen}
                      onChange={(e) => setConfigOpen(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
              </div>

              {/* Multi-Criteria Weight Distribution (50% Student, 20% Peer, 30% Head) */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-indigo-400" />
                  <span>Evaluation Score Weighting Formula (Total: 100%)</span>
                </h3>

                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                    <span>Student Evaluation Weight:</span>
                    <span className="text-amber-400 font-bold">{configStudentWeight}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="70"
                    value={configStudentWeight}
                    onChange={(e) => setConfigStudentWeight(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                    <span>Peer-to-Peer Evaluation Weight:</span>
                    <span className="text-emerald-400 font-bold">{configPeerWeight}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="50"
                    value={configPeerWeight}
                    onChange={(e) => setConfigPeerWeight(Number(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                    <span>Department Head Evaluation Weight:</span>
                    <span className="text-indigo-400 font-bold">{configHeadWeight}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="50"
                    value={configHeadWeight}
                    onChange={(e) => setConfigHeadWeight(Number(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>

                <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-800/40 text-xs text-indigo-300 flex items-center justify-between font-bold">
                  <span>Current Calculated Formula Total:</span>
                  <span className={configStudentWeight + configPeerWeight + configHeadWeight === 100 ? 'text-emerald-400' : 'text-rose-400'}>
                    {configStudentWeight + configPeerWeight + configHeadWeight}%
                  </span>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm shadow-lg shadow-purple-600/30 flex items-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Save System Configuration</span>
            </button>
          </form>
        </div>
      )}

      {/* System Audit Logs Tab */}
      {activeTab === 'system_logs' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <History className="w-5 h-5 text-purple-400" />
                <span>System Security & Action Audit Logs</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Real-time log of user registrations, logins, evaluation submissions, course assignments, and account locks.
              </p>
            </div>
            <button
              onClick={clearSystemLogs}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-300 border border-slate-700 text-xs font-semibold transition-all"
            >
              Clear Logs
            </button>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Timestamp</th>
                    <th className="px-4 py-3">Actor / User</th>
                    <th className="px-4 py-3">Role</th>
                    <th className="px-4 py-3">Action Event</th>
                    <th className="px-4 py-3">Details</th>
                    <th className="px-4 py-3">IP Address</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {logs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-4 py-3 text-slate-400 font-mono text-[11px]">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 font-bold text-slate-100">{log.userName}</td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-800 text-indigo-300 border border-slate-700">
                          {log.userRole}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-semibold text-purple-300">{log.action}</td>
                      <td className="px-4 py-3 text-slate-300">{log.details}</td>
                      <td className="px-4 py-3 text-slate-500 font-mono text-[10px]">{log.ipAddress || '197.156.102.12'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Register User Modal */}
      <Modal
        isOpen={isRegisterModalOpen}
        onClose={() => setIsRegisterModalOpen(false)}
        title="Register New System User"
      >
        <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs">
          {/* Role Selection Navigation Bar (Select Role - Single Navigation) */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">Select User Role</label>
            <div className="flex items-center p-1 rounded-xl bg-slate-950 border border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setRegRole('head');
                  setRegYearLevel('N/A - Faculty');
                }}
                className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  regRole === 'head'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>Department Head</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setRegRole('instructor');
                  setRegYearLevel('N/A - Faculty');
                }}
                className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  regRole === 'instructor'
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <UserCheck2 className="w-3.5 h-3.5" />
                <span>Instructor</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setRegRole('student');
                  setRegYearLevel('Year 1');
                }}
                className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  regRole === 'student'
                    ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <GraduationCap className="w-3.5 h-3.5" />
                <span>Student</span>
              </button>
            </div>
          </div>

          {/* College & Department Selection */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Select College</label>
              <select
                value={regCollege}
                onChange={(e) => handleCollegeChange(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500 font-medium"
              >
                {collegesList.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Select Department</label>
              <select
                value={regDepartment}
                onChange={(e) => setRegDepartment(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500 font-medium"
              >
                {(COLLEGES_AND_DEPARTMENTS[regCollege] || []).map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Academic Session: Year Level, Semester, Academic Year */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Year Level</label>
              <select
                value={regYearLevel}
                onChange={(e) => setRegYearLevel(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
              >
                <option value="Year 1">Year 1</option>
                <option value="Year 2">Year 2</option>
                <option value="Year 3">Year 3</option>
                <option value="Year 4">Year 4</option>
                <option value="Year 5">Year 5</option>
                <option value="N/A - Faculty">N/A - Faculty / Staff</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Semester</label>
              <select
                value={regSemester}
                onChange={(e) => setRegSemester(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
              >
                <option value="Semester I">Semester I</option>
                <option value="Semester II">Semester II</option>
                <option value="Semester III / Summer">Semester III / Summer</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Academic Year</label>
              <select
                value={regAcademicYear}
                onChange={(e) => setRegAcademicYear(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
              >
                <option value="2025/2026">2025/2026</option>
                <option value="2024/2025">2024/2025</option>
                <option value="2023/2024">2023/2024</option>
              </select>
            </div>
          </div>

          {/* Registration Date & Title / Designation */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Registration Date</label>
              <input
                type="date"
                value={regDate}
                onChange={(e) => setRegDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Title / Designation</label>
              <input
                type="text"
                value={regTitle}
                onChange={(e) => setRegTitle(e.target.value)}
                placeholder="e.g. Lecturer, Student, Head"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* User Full Name & Username */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Full Name</label>
              <input
                type="text"
                value={regFullName}
                onChange={(e) => setRegFullName(e.target.value)}
                placeholder="e.g. Abebe Kebede"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Username</label>
              <input
                type="text"
                value={regUsername}
                onChange={(e) => setRegUsername(e.target.value)}
                placeholder="e.g. inst_abebe"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
                required
              />
            </div>
          </div>

          {/* Institutional Email & Initial Password */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Institutional Email</label>
              <input
                type="email"
                value={regEmail}
                onChange={(e) => setRegEmail(e.target.value)}
                placeholder="e.g. abebe@mau.edu.et"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Initial Password</label>
              <input
                type="password"
                value={regPassword}
                onChange={(e) => setRegPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold shadow-lg shadow-purple-600/30 transition-all cursor-pointer mt-2"
          >
            Create User Account
          </button>
        </form>
      </Modal>

      {/* Password Reset Modal */}
      <Modal
        isOpen={!!resetModalUserId}
        onClose={() => setResetModalUserId(null)}
        title="Reset User Password"
      >
        <form onSubmit={handlePasswordResetSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Enter New Password</label>
            <input
              type="password"
              value={newPasswordInput}
              onChange={(e) => setNewPasswordInput(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-purple-500"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold shadow-lg shadow-purple-600/30 transition-all"
          >
            Update Password
          </button>
        </form>
      </Modal>
    </div>
  );
};
