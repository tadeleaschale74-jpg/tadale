import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BookOpen, Users, Target, Send, CheckCircle2, Award, ChevronRight, User } from 'lucide-react';

interface InstructorDashboardProps {
  activeTab: string;
}

export const InstructorDashboard: React.FC<InstructorDashboardProps> = ({ activeTab }) => {
  const {
    currentUser,
    users,
    courses,
    criteria,
    submissions,
    submitEvaluation,
    getInstructorFinalScore,
    showToast,
  } = useApp();

  const [selectedPeerId, setSelectedPeerId] = useState<string | null>(null);
  const [peerScores, setPeerScores] = useState<Record<string, number>>({});
  const [peerComment, setPeerComment] = useState('');

  const dept = currentUser?.department || 'Computer Science';
  const myCourses = courses.filter((c) => c.instructorId === currentUser?.id);
  const reportScore = currentUser ? getInstructorFinalScore(currentUser.id) : null;

  // Other peer instructors in the same department
  const peerInstructors = users.filter(
    (u) => u.role === 'instructor' && u.department === dept && u.id !== currentUser?.id
  );

  const peerCriteriaList = criteria.filter((c) => c.targetRole === 'peer');

  const handlePeerEvalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPeerId || !currentUser) return;

    const targetInstructor = users.find((u) => u.id === selectedPeerId);
    if (!targetInstructor) return;

    const unrated = peerCriteriaList.filter((c) => peerScores[c.id] === undefined);
    if (unrated.length > 0) {
      alert(`Please select a rating for all ${peerCriteriaList.length} criteria before submitting. (${unrated.length} remaining)`);
      return;
    }

    const ratedValues = peerCriteriaList
      .map((c) => peerScores[c.id])
      .filter((v) => typeof v === 'number' && v > 0);

    const avgScore = ratedValues.length > 0
      ? ratedValues.reduce((a, b) => a + b, 0) / ratedValues.length
      : 5;
    const averagePercentage = Math.round((avgScore / 5) * 100);

    submitEvaluation({
      evaluationPeriodId: 'period_2026_sem2',
      evaluatorId: currentUser.id,
      evaluatorName: currentUser.fullName,
      evaluatorRole: 'peer',
      instructorId: targetInstructor.id,
      instructorName: targetInstructor.fullName,
      department: dept,
      scores: peerScores,
      averagePercentage,
      comment: peerComment,
    });

    setSelectedPeerId(null);
    setPeerScores({});
    setPeerComment('');
    showToast('Peer evaluation submitted successfully!', 'success');
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white mb-6">Instructor Dashboard</h2>

      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center gap-3 text-slate-400 mb-2">
                <BookOpen className="w-5 h-5 text-indigo-400" />
                <h3 className="font-semibold text-sm">Assigned Courses</h3>
              </div>
              <div className="text-3xl font-bold text-white">{myCourses.length}</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center gap-3 text-slate-400 mb-2">
                <Users className="w-5 h-5 text-emerald-400" />
                <h3 className="font-semibold text-sm">Student Rating (50%)</h3>
              </div>
              <div className="text-3xl font-bold text-white">
                {reportScore?.studentPercentage || 0}%
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center gap-3 text-slate-400 mb-2">
                <Target className="w-5 h-5 text-amber-400" />
                <h3 className="font-semibold text-sm">Peer Rating (20%)</h3>
              </div>
              <div className="text-3xl font-bold text-white">
                {reportScore?.peerPercentage || 0}%
              </div>
            </div>
            
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center">
               <div className="text-center">
                  <div className="text-xs text-slate-400 mb-1">Total Performance</div>
                  <div className="text-4xl font-black text-indigo-400">{reportScore?.totalFinalScore || 0}%</div>
               </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
             <h3 className="text-lg font-bold text-white mb-4">My Assigned Courses</h3>
             {myCourses.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   {myCourses.map(course => (
                      <div key={course.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                         <div className="text-sm font-bold text-indigo-400 mb-1">{course.code}</div>
                         <div className="font-bold text-white mb-2">{course.title}</div>
                         <div className="text-xs text-slate-400">{course.creditHours} Credit Hours</div>
                      </div>
                   ))}
                </div>
             ) : (
                <p className="text-slate-400 text-sm">No courses assigned to you yet.</p>
             )}
          </div>
        </div>
      )}

      {activeTab === 'assigned_courses' && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-lg font-bold text-white">My Department Assigned Courses</h3>
          <p className="text-xs text-slate-400">Courses officially registered to you under the {dept} department.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {myCourses.map((c) => (
              <div key={c.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-xs font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded">
                    {c.code}
                  </span>
                  <span className="text-xs font-semibold text-slate-400">{c.creditHours} Credit Hours</span>
                </div>
                <h4 className="font-bold text-slate-100">{c.title}</h4>
                <p className="text-xs text-slate-400 mt-1">{c.department} • {c.semester}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Peer-to-Peer Evaluation Tab */}
      {activeTab === 'peer_eval' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-400" />
              <span>Peer-to-Peer Instructor Evaluation (20% Weight Pool)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Evaluate colleague instructors in {dept}. Select a peer to provide ratings on academic competency, ethics, and collaboration.
            </p>
          </div>

          {!selectedPeerId ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {peerInstructors.map((inst) => {
                const existingSub = submissions.find(
                  (s) =>
                    s.evaluatorId === currentUser?.id &&
                    s.instructorId === inst.id &&
                    s.evaluatorRole === 'peer'
                );

                return (
                  <div key={inst.id} className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center font-bold">
                        <User className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-100">{inst.fullName}</h4>
                        <p className="text-xs text-slate-400">{inst.email}</p>
                      </div>
                    </div>

                    <div className="text-xs text-slate-400 flex justify-between items-center pt-2 border-t border-slate-800">
                      <span>Status:</span>
                      {existingSub ? (
                        <span className="text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                          Submitted ({existingSub.averagePercentage}%)
                        </span>
                      ) : (
                        <span className="text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                          Pending Review
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        setSelectedPeerId(inst.id);
                        if (existingSub) {
                          setPeerScores(existingSub.scores);
                          setPeerComment(existingSub.comment || '');
                        } else {
                          setPeerScores({});
                          setPeerComment('');
                        }
                      }}
                      className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                    >
                      <span>{existingSub ? 'Edit Evaluation' : 'Evaluate Colleague'}</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Peer Evaluation Form View */
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
                <div>
                  <div className="text-xs text-indigo-400 font-bold uppercase tracking-wider">
                    Peer Evaluation Form
                  </div>
                  <h3 className="text-lg font-bold text-slate-100">
                    Evaluating {users.find((u) => u.id === selectedPeerId)?.fullName}
                  </h3>
                  <div className="text-xs text-slate-400 mt-1">
                    {peerCriteriaList.length} Evaluation Criteria • Radio Buttons • Weight: 20%
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const fullHigh: Record<string, number> = {};
                      peerCriteriaList.forEach((c) => {
                        fullHigh[c.id] = 5;
                      });
                      setPeerScores(fullHigh);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold cursor-pointer transition-all"
                  >
                    Auto-Fill All Excellent (5)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedPeerId(null)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>

              {/* Real-time Progress Counter */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 flex flex-wrap items-center justify-between gap-2">
                <span className="font-bold text-indigo-300">
                  Progress: {Object.keys(peerScores).length} of {peerCriteriaList.length} criteria answered
                </span>
                <div className="flex flex-wrap gap-2.5 font-mono text-[11px]">
                  <span className="text-red-400">1 = Very Low</span>
                  <span className="text-amber-400">2 = Low</span>
                  <span className="text-yellow-400">3 = Average</span>
                  <span className="text-blue-400">4 = High</span>
                  <span className="text-emerald-400">5 = Very High</span>
                  <span className="text-slate-400">0 = N/A</span>
                </div>
              </div>

              <form onSubmit={handlePeerEvalSubmit} className="space-y-6">
                <div className="space-y-4">
                  {peerCriteriaList.map((crit, idx) => {
                    const isAnswered = peerScores[crit.id] !== undefined;
                    return (
                      <div
                        key={crit.id}
                        className={`p-4 rounded-xl border transition-all ${
                          isAnswered
                            ? 'bg-slate-950/80 border-slate-800'
                            : 'bg-amber-950/10 border-amber-500/30'
                        }`}
                      >
                        <div className="flex justify-between items-start gap-4 mb-2">
                          <span className="text-xs font-bold text-indigo-300">
                            Criterion #{idx + 1} • {crit.category}
                          </span>
                          {!isAnswered && (
                            <span className="text-[10px] uppercase font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
                              Required
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-100 font-medium mb-3">{crit.questionText}</p>

                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                          {[
                            { value: 1, label: '1 - VL', color: 'text-red-400' },
                            { value: 2, label: '2 - L', color: 'text-amber-400' },
                            { value: 3, label: '3 - A', color: 'text-yellow-400' },
                            { value: 4, label: '4 - H', color: 'text-blue-400' },
                            { value: 5, label: '5 - VH', color: 'text-emerald-400' },
                            { value: 0, label: 'N/A', color: 'text-slate-400' },
                          ].map((opt) => {
                            const selected = peerScores[crit.id] === opt.value;
                            return (
                              <label
                                key={opt.value}
                                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold cursor-pointer border transition-all ${
                                  selected
                                    ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-md shadow-indigo-600/20'
                                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/60'
                                }`}
                              >
                                <input
                                  type="radio"
                                  name={`peer_crit_${crit.id}`}
                                  value={opt.value}
                                  checked={selected}
                                  onChange={() =>
                                    setPeerScores((prev) => ({ ...prev, [crit.id]: opt.value }))
                                  }
                                  className="w-4 h-4 text-indigo-600 bg-slate-950 border-slate-700 focus:ring-indigo-500 cursor-pointer"
                                />
                                <span className={selected ? 'text-indigo-200' : opt.color}>
                                  {opt.label}
                                </span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Peer Evaluation Comment / Recommendations (Optional)
                  </label>
                  <textarea
                    rows={3}
                    value={peerComment}
                    onChange={(e) => setPeerComment(e.target.value)}
                    placeholder="Provide constructive feedback regarding colleague performance..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="text-xs text-slate-400">
                    Answered: <strong className="text-indigo-300">{Object.keys(peerScores).length}</strong> of <strong className="text-slate-200">{peerCriteriaList.length}</strong> criteria
                  </div>
                  <button
                    type="submit"
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Submit Peer Evaluation ({peerCriteriaList.length} Criteria • 20% Weight)</span>
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* 100% Performance Score Tab */}
      {activeTab === 'my_performance' && reportScore && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="flex justify-between items-center border-b border-slate-800 pb-4">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-indigo-400">Performance Overview</div>
              <h3 className="text-xl font-bold text-white">{currentUser?.fullName}</h3>
              <p className="text-xs text-slate-400">{dept}</p>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-400">Comprehensive Score</div>
              <div className="text-3xl font-black text-indigo-400">{reportScore.totalFinalScore}%</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-xs font-bold text-amber-400 mb-1">1. Student Pool (50%)</div>
              <div className="text-2xl font-bold text-white">{reportScore.studentScore} / 50 pts</div>
              <div className="text-xs text-slate-400 mt-1">Average rating: {reportScore.studentPercentage}%</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-xs font-bold text-emerald-400 mb-1">2. Peer Pool (20%)</div>
              <div className="text-2xl font-bold text-white">{reportScore.peerScore} / 20 pts</div>
              <div className="text-xs text-slate-400 mt-1">Average rating: {reportScore.peerPercentage}%</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-xs font-bold text-indigo-400 mb-1">3. Head Pool (30%)</div>
              <div className="text-2xl font-bold text-white">{reportScore.headScore} / 30 pts</div>
              <div className="text-xs text-slate-400 mt-1">
                Status: {reportScore.headSubmitted ? 'Submitted' : 'Pending'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
