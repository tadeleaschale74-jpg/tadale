import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Building2,
  BookOpen,
  Send,
  Users,
  Award,
  GraduationCap,
  CheckCircle2,
  AlertCircle,
  Plus,
  FileCheck,
  ChevronRight,
  TrendingUp,
  BarChart2,
  Printer,
  Sparkles,
  Info,
  Calendar,
} from 'lucide-react';
import { Modal } from '../common/Modal';
import { EvaluationSubmission } from '../../types';

interface HeadDashboardProps {
  activeTab: string;
}

import { getAccessToken, googleSignIn } from '../../auth';

export const HeadDashboard: React.FC<HeadDashboardProps> = ({ activeTab }) => {
  const {
    currentUser,
    users,
    courses,
    criteria,
    submissions,
    publishedForms,
    publishedPeerForms,
    systemConfig,
    assignCourseInstructor,
    addCourse,
    publishEvaluationForm,
    publishPeerEvaluationForm,
    submitEvaluation,
    getAllInstructorsScoresByDepartment,
    getInstructorFinalScore,
    showToast,
  } = useApp();

  const [isExporting, setIsExporting] = useState(false);

  const handleExportToDrive = async (reportScore: any) => {
    try {
      setIsExporting(true);
      let token = await getAccessToken();
      if (!token) {
        const result = await googleSignIn();
        if (result) {
          token = result.accessToken;
        } else {
          throw new Error('Google Sign-In failed or was cancelled.');
        }
      }

      const assignedCourses = departmentCourses.filter(c => c.instructorId === reportScore.instructorId);
      const courseText = assignedCourses.length > 0 
        ? assignedCourses.map(c => `- ${c.code}: ${c.title} (${c.creditHours} Cr.Hrs)`).join('\n')
        : 'No courses assigned';

      const reportContent = `MAU Official Instructor Performance Report Card
Instructor: ${reportScore.instructorName}
Department: ${reportScore.department}
Academic Year: ${systemConfig.academicYear} • ${systemConfig.semester}
Date: ${new Date().toLocaleDateString()}

Assigned Courses:
${courseText}

1. Student Evaluation Pool (50%)
Score: ${reportScore.studentScore} / 50 pts
Average Rating: ${reportScore.studentPercentage}%

2. Peer-to-Peer Evaluation Pool (20%)
Score: ${reportScore.peerScore} / 20 pts
Average Rating: ${reportScore.peerPercentage}%

3. Department Head Evaluation Pool (30%)
Score: ${reportScore.headScore} / 30 pts
Status: ${reportScore.headSubmitted ? 'Submitted' : 'Pending'}

Final Comprehensive Score: ${reportScore.totalFinalScore} / 100%
Performance Status Grade: ${reportScore.grade}
`;

      const metadata = {
        name: `Instructor_Performance_Report_${reportScore.instructorName.replace(/\s+/g, '_')}.txt`,
        mimeType: 'text/plain',
      };

      const form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', new Blob([reportContent], { type: 'text/plain' }));

      const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`
        },
        body: form
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`Failed to upload to Google Drive: ${errText}`);
      }

      showToast('Report successfully exported to Google Drive!', 'success');
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Error exporting to Google Drive', 'error');
    } finally {
      setIsExporting(false);
    }
  };

  const dept = currentUser?.department || 'Computer Science';

  // Instructors in Head's department
  const departmentInstructors = users.filter((u) => u.role === 'instructor' && u.department === dept);
  const departmentStudents = users.filter((u) => u.role === 'student' && u.department === dept);
  const departmentCourses = courses.filter((c) => c.department === dept);

  // Selected Instructor for Head Evaluation form
  const [selectedInstForEval, setSelectedInstForEval] = useState<string | null>(null);
  const [headScores, setHeadScores] = useState<Record<string, number>>({});
  const [headComment, setHeadComment] = useState('');

  // Course Modal state
  const [isAddCourseModalOpen, setIsAddCourseModalOpen] = useState(false);
  const [newCode, setNewCode] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newCredit, setNewCredit] = useState(3);
  const [newInstructorId, setNewInstructorId] = useState<string>('');

  // Report Modal state
  const [selectedReportInstId, setSelectedReportInstId] = useState<string | null>(null);

  // Publish Form to Students Modal State
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [pubInstructorId, setPubInstructorId] = useState<string>('');
  const [pubCourseId, setPubCourseId] = useState<string>('');
  const [pubYearLevel, setPubYearLevel] = useState<string>('All Year Levels');
  const [pubSemester, setPubSemester] = useState<string>(systemConfig.semester || 'Semester II');
  const [pubAcademicYear, setPubAcademicYear] = useState<string>(systemConfig.academicYear || '2025/2026');

  // When opening publish modal, auto-select first instructor if available
  const handleOpenPublishModal = () => {
    if (departmentInstructors.length > 0) {
      const firstInst = departmentInstructors[0];
      setPubInstructorId(firstInst.id);
      const instCourses = departmentCourses.filter((c) => c.instructorId === firstInst.id);
      if (instCourses.length > 0) {
        setPubCourseId(instCourses[0].id);
      } else {
        setPubCourseId('');
      }
    } else {
      setPubInstructorId('');
      setPubCourseId('');
    }
    setIsPublishModalOpen(true);
  };

  const handleInstructorChangeForPublish = (instId: string) => {
    setPubInstructorId(instId);
    const instCourses = departmentCourses.filter((c) => c.instructorId === instId);
    if (instCourses.length > 0) {
      setPubCourseId(instCourses[0].id);
    } else {
      setPubCourseId('');
    }
  };

  const handlePublishFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pubInstructorId) {
      alert('Please select an instructor to evaluate.');
      return;
    }

    const inst = users.find((u) => u.id === pubInstructorId);
    const crs = courses.find((c) => c.id === pubCourseId);

    // Filter matched students
    const matchedStudents = departmentStudents.filter((s) => {
      const matchYear = pubYearLevel === 'All Year Levels' || s.yearLevel === pubYearLevel;
      return matchYear;
    });

    const studentCount = matchedStudents.length > 0 ? matchedStudents.length : departmentStudents.length;

    publishEvaluationForm({
      department: dept,
      instructorId: pubInstructorId,
      instructorName: inst ? inst.fullName : 'Selected Instructor',
      courseId: crs ? crs.id : 'crs_general',
      courseCode: crs ? crs.code : 'GEN101',
      courseTitle: crs ? crs.title : 'Department Course',
      yearLevel: pubYearLevel,
      semester: pubSemester,
      academicYear: pubAcademicYear,
      targetStudentCount: studentCount,
      publishedBy: currentUser?.fullName || 'Department Head',
    });

    setIsPublishModalOpen(false);
  };

  // Publish Peer-to-Peer Evaluation Form Modal State
  const [isPeerPublishModalOpen, setIsPeerPublishModalOpen] = useState(false);
  const [peerPubTargetInstId, setPeerPubTargetInstId] = useState<string>('');
  const [peerPubSemester, setPeerPubSemester] = useState<string>(systemConfig.semester || 'Semester II');
  const [peerPubAcademicYear, setPeerPubAcademicYear] = useState<string>(systemConfig.academicYear || '2025/2026');

  const handleOpenPeerPublishModal = () => {
    if (departmentInstructors.length > 0) {
      setPeerPubTargetInstId(departmentInstructors[0].id);
    } else {
      setPeerPubTargetInstId('');
    }
    setIsPeerPublishModalOpen(true);
  };

  const handlePeerPublishFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!peerPubTargetInstId) {
      alert('Please select a target instructor to evaluate.');
      return;
    }

    const targetInst = users.find((u) => u.id === peerPubTargetInstId);
    const peerColleagues = departmentInstructors.filter((u) => u.id !== peerPubTargetInstId);
    const peerCount = peerColleagues.length > 0 ? peerColleagues.length : Math.max(1, departmentInstructors.length - 1);

    publishPeerEvaluationForm({
      department: dept,
      targetInstructorId: peerPubTargetInstId,
      targetInstructorName: targetInst ? targetInst.fullName : 'Selected Instructor',
      semester: peerPubSemester,
      academicYear: peerPubAcademicYear,
      targetPeerCount: peerCount,
      publishedBy: currentUser?.fullName || 'Department Head',
    });

    setIsPeerPublishModalOpen(false);
  };

  // Formal Print Function
  const handlePrintFormalReport = (reportScore: any) => {
    const printWindow = window.open('', '_blank', 'width=850,height=950');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>MAU Official Report Card - ${reportScore.instructorName}</title>
            <style>
              body {
                font-family: 'Segoe UI', Arial, sans-serif;
                margin: 0;
                padding: 40px;
                color: #0f172a;
                background-color: #ffffff;
              }
              .header {
                text-align: center;
                border-bottom: 2px solid #0f172a;
                padding-bottom: 15px;
                margin-bottom: 25px;
              }
              .header h1 {
                font-size: 20px;
                margin: 0;
                color: #0f172a;
                text-transform: uppercase;
                letter-spacing: 1px;
              }
              .header h2 {
                font-size: 15px;
                margin: 6px 0 0 0;
                color: #2563eb;
              }
              .header p {
                font-size: 12px;
                color: #64748b;
                margin-top: 4px;
              }
              .info-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 15px;
                background: #f8fafc;
                border: 1px solid #cbd5e1;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 25px;
              }
              .info-label {
                font-size: 11px;
                color: #64748b;
                text-transform: uppercase;
                font-weight: bold;
              }
              .info-value {
                font-size: 14px;
                font-weight: bold;
                color: #0f172a;
                margin-top: 2px;
              }
              table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 25px;
              }
              th, td {
                padding: 12px 15px;
                text-align: left;
                border-bottom: 1px solid #e2e8f0;
              }
              th {
                background-color: #0f172a;
                color: #ffffff;
                font-size: 12px;
                text-transform: uppercase;
              }
              td {
                font-size: 13px;
              }
              .total-box {
                background: #f1f5f9;
                border: 2px solid #0f172a;
                border-radius: 8px;
                padding: 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 40px;
              }
              .total-score {
                font-size: 28px;
                font-weight: 900;
                color: #0f172a;
              }
              .total-grade {
                font-size: 18px;
                font-weight: 800;
                color: #16a34a;
              }
              .signatures {
                margin-top: 60px;
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 40px;
              }
              .sig-line {
                border-top: 1px dashed #64748b;
                padding-top: 8px;
                font-size: 12px;
                color: #334155;
                text-align: center;
                font-weight: bold;
              }
              .seal-stamp {
                text-align: center;
                margin-top: 35px;
                font-size: 11px;
                color: #64748b;
                font-style: italic;
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>Mekdela Amba University (MAU)</h1>
              <h2>Office of Academic Quality Assurance & Performance Evaluation</h2>
              <p>Official Instructor Performance Certificate • ${systemConfig.academicYear} ${systemConfig.semester}</p>
            </div>

            <div class="info-grid">
              <div>
                <div class="info-label">Instructor Name</div>
                <div class="info-value">${reportScore.instructorName}</div>
              </div>
              <div>
                <div class="info-label">Department</div>
                <div class="info-value">${reportScore.department}</div>
              </div>
              <div>
                <div class="info-label">Evaluation Period</div>
                <div class="info-value">${systemConfig.academicYear} • ${systemConfig.semester}</div>
              </div>
              <div>
                <div class="info-label">Report Generation Date</div>
                <div class="info-value">${new Date().toLocaleDateString()}</div>
              </div>
              <div style="grid-column: 1 / -1;">
                <div class="info-label">Assigned Courses & Credit Hours</div>
                <div class="info-value" style="font-weight: normal; font-size: 13px;">
                  ${departmentCourses.filter(c => c.instructorId === reportScore.instructorId).length > 0 
                    ? `<ul style="margin: 4px 0 0 0; padding-left: 20px;">` + departmentCourses.filter(c => c.instructorId === reportScore.instructorId).map(c => `<li>${c.code} - ${c.title} (${c.creditHours} Cr.Hrs)</li>`).join('') + `</ul>`
                    : `<em>No courses assigned</em>`
                  }
                </div>
              </div>
            </div>

            <table>
              <thead>
                <tr>
                  <th>Multi-Evaluator Pool Component</th>
                  <th>Formula Weight</th>
                  <th>Average Rating %</th>
                  <th>Points Earned</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><strong>1. Student Evaluation Pool</strong></td>
                  <td>50%</td>
                  <td>${reportScore.studentPercentage}%</td>
                  <td><strong>${reportScore.studentScore} / 50 pts</strong></td>
                </tr>
                <tr>
                  <td><strong>2. Peer-to-Peer Evaluation Pool</strong></td>
                  <td>20%</td>
                  <td>${reportScore.peerPercentage}%</td>
                  <td><strong>${reportScore.peerScore} / 20 pts</strong></td>
                </tr>
                <tr>
                  <td><strong>3. Department Head Evaluation Pool</strong></td>
                  <td>30%</td>
                  <td>${reportScore.headPercentage}%</td>
                  <td><strong>${reportScore.headScore} / 30 pts</strong></td>
                </tr>
              </tbody>
            </table>

            <div class="total-box">
              <div>
                <div style="font-size: 11px; text-transform: uppercase; color: #475569; font-weight: bold;">Final Comprehensive Score</div>
                <div class="total-score">${reportScore.totalFinalScore} <span style="font-size: 16px; font-weight: normal; color: #64748b;">/ 100%</span></div>
              </div>
              <div style="text-align: right;">
                <div style="font-size: 11px; color: #475569; font-weight: bold;">Performance Status Grade</div>
                <div class="total-grade">${reportScore.grade}</div>
              </div>
            </div>

            <div class="signatures">
              <div>
                <div class="sig-line">Department Head Signature & Date</div>
              </div>
              <div>
                <div class="sig-line">Academic Vice President / Quality Director</div>
              </div>
            </div>

            <div class="seal-stamp">
              *** Official Seal Stamp • MAU Instructor Performance Evaluation System (MAU-IPES) ***
            </div>

            <script>
              window.onload = function() {
                window.print();
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    } else {
      window.print();
    }
  };

  // Head Criteria
  const headCriteriaList = criteria.filter((c) => c.targetRole === 'head');

  const handleHeadEvalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInstForEval) return;

    const targetInstructor = users.find((u) => u.id === selectedInstForEval);
    if (!targetInstructor) return;

    // Check if all criteria have been answered with a radio selection (1-5 or 0 for NA)
    const unrated = headCriteriaList.filter((c) => headScores[c.id] === undefined);
    if (unrated.length > 0) {
      alert(`Please select a rating option for all ${headCriteriaList.length} criteria before submitting. (${unrated.length} remaining)`);
      return;
    }

    // Calculate percentage average from rated criteria (ignoring 0/NA)
    const ratedValues = headCriteriaList
      .map((c) => headScores[c.id])
      .filter((v) => typeof v === 'number' && v > 0);

    const avgScore = ratedValues.length > 0
      ? ratedValues.reduce((a, b) => a + b, 0) / ratedValues.length
      : 5;
    const averagePercentage = Math.round((avgScore / 5) * 100);

    submitEvaluation({
      evaluationPeriodId: 'period_2026_sem2',
      evaluatorId: currentUser?.id || 'head',
      evaluatorName: currentUser?.fullName || 'Department Head',
      evaluatorRole: 'head',
      instructorId: targetInstructor.id,
      instructorName: targetInstructor.fullName,
      department: dept,
      scores: headScores,
      averagePercentage,
      comment: headComment || 'Department Head official evaluation submitted.',
    });

    setSelectedInstForEval(null);
    setHeadScores({});
    setHeadComment('');
  };

  const handleAddCourseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode || !newTitle) return;

    addCourse({
      code: newCode,
      title: newTitle,
      department: dept,
      creditHours: newCredit,
      instructorId: newInstructorId || null,
      semester: systemConfig.semester,
    });

    setIsAddCourseModalOpen(false);
    setNewCode('');
    setNewTitle('');
    setNewCredit(3);
    setNewInstructorId('');
  };

  const instructorsScores = getAllInstructorsScoresByDepartment(dept);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-950 via-blue-900/60 to-slate-900 border border-indigo-800/50 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2">
            <Building2 className="w-3.5 h-3.5 text-indigo-400" />
            <span>{dept} Department Head Portal</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100">Academic Instructor Performance Management</h2>
          <p className="text-xs text-slate-300 mt-1">
            Assign courses, publish student evaluations, monitor peer ratings (20%), complete head evaluations (30%), and generate 100% final scores.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xl bg-indigo-900/50 border border-indigo-700/50 text-indigo-200 text-xs font-bold">
            {departmentInstructors.length} Instructors
          </span>
          <span className="px-3 py-1.5 rounded-xl bg-amber-900/50 border border-amber-700/50 text-amber-200 text-xs font-bold">
            {departmentStudents.length} Students
          </span>
        </div>
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Metrics Overview Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1 font-semibold">
                <span>Student Submissions Pool</span>
                <span className="text-amber-400 font-bold">50% Weight</span>
              </div>
              <div className="text-2xl font-black text-slate-100">
                {submissions.filter((s) => s.department === dept && s.evaluatorRole === 'student').length}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">From {departmentStudents.length} department students</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1 font-semibold">
                <span>Peer Evaluation Pool</span>
                <span className="text-emerald-400 font-bold">20% Weight</span>
              </div>
              <div className="text-2xl font-black text-slate-100">
                {submissions.filter((s) => s.department === dept && s.evaluatorRole === 'peer').length}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Instructor to instructor peer reviews</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1 font-semibold">
                <span>Head Evaluations Done</span>
                <span className="text-indigo-400 font-bold">30% Weight</span>
              </div>
              <div className="text-2xl font-black text-slate-100">
                {submissions.filter((s) => s.department === dept && s.evaluatorRole === 'head').length} / {departmentInstructors.length}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Individual instructor head ratings</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1 font-semibold">
                <span>Assigned Courses</span>
                <span className="text-blue-400 font-bold">MAU Curriculum</span>
              </div>
              <div className="text-2xl font-black text-slate-100">
                {departmentCourses.filter((c) => c.instructorId).length} / {departmentCourses.length}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Active courses in {dept}</div>
            </div>
          </div>

          {/* Quick Department Instructor Status List */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Award className="w-4 h-4 text-indigo-400" />
              <span>Department Instructors Performance Score Progress</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {instructorsScores.map((score) => (
                <div key={score.instructorId} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-bold text-sm text-slate-100">{score.instructorName}</div>
                      <div className="text-xs text-slate-400">{dept}</div>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-xs font-black bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {score.totalFinalScore}%
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Student Pool (50%):</span>
                      <span className="font-bold text-amber-400">
                        {score.studentScore} / 50 pts ({score.studentSubmissionsCount} / {score.studentTargetCount} students)
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-amber-400 h-full" style={{ width: `${(score.studentScore / 50) * 100}%` }} />
                    </div>

                    <div className="flex justify-between pt-1">
                      <span className="text-slate-400">Peer Pool (20%):</span>
                      <span className="font-bold text-emerald-400">
                        {score.peerScore} / 20 pts ({score.peerSubmissionsCount} / {score.peerTargetCount} peers)
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-emerald-400 h-full" style={{ width: `${(score.peerScore / 20) * 100}%` }} />
                    </div>

                    <div className="flex justify-between pt-1">
                      <span className="text-slate-400">Head Pool (30%):</span>
                      <span className="font-bold text-indigo-400">
                        {score.headSubmitted ? `${score.headScore} / 30 pts (Done)` : '0 / 30 pts (Pending)'}
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-indigo-400 h-full" style={{ width: `${(score.headScore / 30) * 100}%` }} />
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedReportInstId(score.instructorId)}
                    className="w-full mt-2 py-2 rounded-xl bg-slate-900 hover:bg-indigo-950 text-indigo-300 border border-slate-800 hover:border-indigo-700/50 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                  >
                    <BarChart2 className="w-3.5 h-3.5" />
                    <span>View 100% Score Report Card</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Course Assignment Tab */}
      {activeTab === 'assign_courses' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-indigo-400" />
                <span>Department Course Assignment to Instructors</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Assign curriculum courses to instructors in {dept}. Assigned instructors become available for student evaluation.
              </p>
            </div>
            <button
              onClick={() => setIsAddCourseModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Department Course</span>
            </button>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3.5">Course Code & Title</th>
                    <th className="px-4 py-3.5">Credit Hours</th>
                    <th className="px-4 py-3.5">Semester</th>
                    <th className="px-4 py-3.5">Assigned Instructor</th>
                    <th className="px-4 py-3.5 text-right">Assign Instructor Control</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {departmentCourses.map((crs) => {
                    const assignedInst = departmentInstructors.find((i) => i.id === crs.instructorId);
                    return (
                      <tr key={crs.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="px-4 py-3.5 font-bold text-slate-100">
                          <div className="text-sm text-indigo-300">{crs.code}</div>
                          <div className="text-slate-300 font-normal">{crs.title}</div>
                        </td>
                        <td className="px-4 py-3.5 text-slate-300 font-semibold">{crs.creditHours} Cr.Hrs</td>
                        <td className="px-4 py-3.5 text-slate-400">{crs.semester}</td>
                        <td className="px-4 py-3.5">
                          {assignedInst ? (
                            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 font-semibold">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span>{assignedInst.fullName}</span>
                            </div>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/30 font-semibold">
                              <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                              <span>Unassigned</span>
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3.5 text-right">
                          <select
                            value={crs.instructorId || ''}
                            onChange={(e) => assignCourseInstructor(crs.id, e.target.value || null)}
                            className="bg-slate-950 border border-slate-700 text-xs text-slate-200 rounded-xl px-3 py-1.5 focus:outline-none focus:border-indigo-500"
                          >
                            <option value="">-- Unassigned --</option>
                            {departmentInstructors.map((inst) => (
                              <option key={inst.id} value={inst.id}>
                                {inst.fullName} ({inst.title})
                              </option>
                            ))}
                          </select>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Student Evaluation Pool Monitor (50%) */}
      {activeTab === 'student_eval_pool' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-amber-400" />
                <span>Student Evaluation Arrival Pool (50% Score Contribution)</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Student evaluations submitted by students in {dept} for department instructors.
              </p>
            </div>
            <button
              onClick={handleOpenPublishModal}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-amber-600/20"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Publish Form to Students</span>
            </button>
          </div>

          {/* Published Dispatches Summary */}
          {publishedForms.filter((pf) => pf.department === dept).length > 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  <span>Active Dispatched Forms ({publishedForms.filter((pf) => pf.department === dept).length})</span>
                </h3>
                <span className="text-[11px] text-slate-400">Published to target department students</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {publishedForms
                  .filter((pf) => pf.department === dept)
                  .map((pf) => (
                    <div key={pf.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2 text-xs">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-bold text-slate-100">{pf.instructorName}</div>
                          <div className="text-[11px] text-indigo-400 font-mono font-semibold">{pf.courseCode} - {pf.courseTitle}</div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                          {pf.targetStudentCount} Students
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-900 flex justify-between items-center">
                        <span>{pf.yearLevel} • {pf.semester}</span>
                        <span>{new Date(pf.publishedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Evaluated Instructor</th>
                    <th className="px-4 py-3">Student Evaluator</th>
                    <th className="px-4 py-3">Course Code</th>
                    <th className="px-4 py-3">Rating Score</th>
                    <th className="px-4 py-3">Student Comments</th>
                    <th className="px-4 py-3">Date Submitted</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {submissions
                    .filter((s) => s.department === dept && s.evaluatorRole === 'student')
                    .map((s) => (
                      <tr key={s.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="px-4 py-3 font-bold text-slate-100">{s.instructorName}</td>
                        <td className="px-4 py-3 text-slate-300">{s.evaluatorName}</td>
                        <td className="px-4 py-3 font-mono text-indigo-300">{s.courseCode || 'N/A'}</td>
                        <td className="px-4 py-3">
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            {s.averagePercentage}%
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-300 italic max-w-xs truncate">
                          "{s.comment || 'No comment'}"
                        </td>
                        <td className="px-4 py-3 text-slate-400 text-[11px]">
                          {new Date(s.submittedAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Peer Evaluation Pool Monitor (20%) */}
      {activeTab === 'peer_eval_pool' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-400" />
                <span>Peer-to-Peer Instructor Evaluation Pool (20% Score Contribution)</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Colleague instructor reviews submitted within {dept} department.
              </p>
            </div>
            <button
              onClick={handleOpenPeerPublishModal}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-600/20 shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Peer Eval Form to Instructors</span>
            </button>
          </div>

          {/* Published Peer Dispatches Summary */}
          {publishedPeerForms.filter((pf) => pf.department === dept).length > 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  <span>Active Dispatched Peer Forms ({publishedPeerForms.filter((pf) => pf.department === dept).length})</span>
                </h3>
                <span className="text-[11px] text-slate-400">Published to colleague instructors in {dept}</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {publishedPeerForms
                  .filter((pf) => pf.department === dept)
                  .map((pf) => (
                    <div key={pf.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2 text-xs">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="text-[10px] text-emerald-400 font-bold uppercase">Target Colleague</div>
                          <div className="font-bold text-slate-100">{pf.targetInstructorName}</div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                          {pf.targetPeerCount} Peer Evaluators
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-900 flex justify-between items-center">
                        <span>{pf.semester} • {pf.academicYear}</span>
                        <span>{new Date(pf.publishedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Target Instructor</th>
                    <th className="px-4 py-3">Peer Evaluator (Instructor)</th>
                    <th className="px-4 py-3">Peer Rating Score</th>
                    <th className="px-4 py-3">Peer Feedback Notes</th>
                    <th className="px-4 py-3">Submitted At</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {submissions
                    .filter((s) => s.department === dept && s.evaluatorRole === 'peer')
                    .map((s) => (
                      <tr key={s.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="px-4 py-3 font-bold text-slate-100">{s.instructorName}</td>
                        <td className="px-4 py-3 text-slate-300">{s.evaluatorName}</td>
                        <td className="px-4 py-3">
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            {s.averagePercentage}%
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-300 italic">{s.comment || 'N/A'}</td>
                        <td className="px-4 py-3 text-slate-400 text-[11px]">
                          {new Date(s.submittedAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Head Evaluation Submission Form (30%) */}
      {activeTab === 'submit_head_eval' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Send className="w-5 h-5 text-indigo-400" />
              <span>Submit Department Head Evaluation (30% Contribution)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Select an instructor in {dept} and rate them on administrative compliance, teaching quality, research, and ethics.
            </p>
          </div>

          {!selectedInstForEval ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {departmentInstructors.map((inst) => {
                const headSub = submissions.find(
                  (s) => s.instructorId === inst.id && s.evaluatorRole === 'head'
                );

                return (
                  <div
                    key={inst.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between space-y-4"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-xs font-bold uppercase tracking-wider text-indigo-400">{inst.title}</div>
                        <div className="flex items-center gap-1.5 flex-wrap justify-end">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            Active
                          </span>
                          {headSub ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                              Completed ({headSub.averagePercentage}%)
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                              Pending Head Evaluation
                            </span>
                          )}
                        </div>
                      </div>
                      <h3 className="text-base font-bold text-slate-100">{inst.fullName}</h3>
                      <p className="text-xs text-slate-400 truncate">{inst.email}</p>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedInstForEval(inst.id);
                        if (headSub) {
                          setHeadScores(headSub.scores);
                          setHeadComment(headSub.comment || '');
                        } else {
                          setHeadScores({});
                          setHeadComment('');
                        }
                      }}
                      className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <span>{headSub ? 'Edit Head Evaluation' : 'Evaluate Instructor Now'}</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Head Evaluation Form View with Radio Buttons for 24 Criteria */
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
                <div>
                  <div className="text-xs text-indigo-400 font-bold uppercase tracking-wider">Evaluating Instructor</div>
                  <h3 className="text-lg font-bold text-slate-100">
                    {users.find((u) => u.id === selectedInstForEval)?.fullName}
                  </h3>
                  <div className="text-xs text-slate-400 mt-1">
                    {headCriteriaList.length} Evaluation Criteria • Radio Buttons • Weight: 30%
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const fullExcellent: Record<string, number> = {};
                      headCriteriaList.forEach((c) => {
                        fullExcellent[c.id] = 5;
                      });
                      setHeadScores(fullExcellent);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold cursor-pointer transition-all"
                  >
                    Auto-Fill All Very High (5)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedInstForEval(null)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                  >
                    Cancel / Back
                  </button>
                </div>
              </div>

              {/* Rating Scale Legend & Real-Time Progress */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-indigo-300">
                    Progress: {headCriteriaList.filter((c) => headScores[c.id] !== undefined).length} of {headCriteriaList.length} criteria answered
                  </span>
                  {headCriteriaList.filter((c) => headScores[c.id] !== undefined).length === headCriteriaList.length && (
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      ✓ All Criteria Completed
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap gap-2.5 font-mono text-[11px]">
                  <span className="text-red-400">1 = Very Low (VL)</span>
                  <span className="text-amber-400">2 = Low (L)</span>
                  <span className="text-yellow-400">3 = Average (A)</span>
                  <span className="text-blue-400">4 = High (H)</span>
                  <span className="text-emerald-400">5 = Very High (VH)</span>
                  <span className="text-slate-400">0 = N/A</span>
                </div>
              </div>

              <form onSubmit={handleHeadEvalSubmit} className="space-y-6">
                <div className="space-y-4">
                  {headCriteriaList.map((crit, idx) => {
                    const isAnswered = headScores[crit.id] !== undefined;
                    return (
                      <div
                        key={crit.id}
                        className={`p-4 rounded-xl border transition-all ${
                          isAnswered
                            ? 'bg-slate-950/80 border-slate-800'
                            : 'bg-amber-950/10 border-amber-500/30'
                        }`}
                      >
                        <div className="flex justify-between items-start gap-4 mb-2">
                          <span className="text-xs font-bold text-indigo-300">
                            Criterion #{idx + 1} • {crit.category}
                          </span>
                          {!isAnswered && (
                            <span className="text-[10px] uppercase font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
                              Required
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-100 font-medium mb-3">{crit.questionText}</p>

                        {/* Radio Button Options Group */}
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                          {[
                            { value: 1, label: '1 - VL', color: 'text-red-400' },
                            { value: 2, label: '2 - L', color: 'text-amber-400' },
                            { value: 3, label: '3 - A', color: 'text-yellow-400' },
                            { value: 4, label: '4 - H', color: 'text-blue-400' },
                            { value: 5, label: '5 - VH', color: 'text-emerald-400' },
                            { value: 0, label: 'N/A', color: 'text-slate-400' },
                          ].map((opt) => {
                            const selected = headScores[crit.id] === opt.value;
                            return (
                              <label
                                key={opt.value}
                                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold cursor-pointer border transition-all ${
                                  selected
                                    ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-md shadow-indigo-600/20'
                                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/60'
                                }`}
                              >
                                <input
                                  type="radio"
                                  name={`head_crit_${crit.id}`}
                                  value={opt.value}
                                  checked={selected}
                                  onChange={() =>
                                    setHeadScores((prev) => ({ ...prev, [crit.id]: opt.value }))
                                  }
                                  className="w-4 h-4 text-indigo-600 bg-slate-950 border-slate-700 focus:ring-indigo-500 cursor-pointer"
                                />
                                <span className={selected ? 'text-indigo-200' : opt.color}>
                                  {opt.label}
                                </span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Department Head Remarks / Recommendation Comment
                  </label>
                  <textarea
                    rows={3}
                    value={headComment}
                    onChange={(e) => setHeadComment(e.target.value)}
                    placeholder="Enter formal departmental evaluation notes, strengths, or recommendations for promotion..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="text-xs text-slate-400">
                    Answered: <strong className="text-indigo-300">{headCriteriaList.filter((c) => headScores[c.id] !== undefined).length}</strong> of <strong className="text-slate-200">{headCriteriaList.length}</strong> criteria
                  </div>
                  <button
                    type="submit"
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Submit Head Evaluation ({headCriteriaList.length} Criteria • 30% Weight)</span>
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* 100% Comprehensive Final Score Calculation Tab */}
      {activeTab === 'final_calculation' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <Award className="w-5 h-5 text-indigo-400" />
                <span>Final 100% Comprehensive Score Calculation Directory</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Integrated score formula: Student (50%) + Peer (20%) + Head (30%) = 100% Performance Score.
              </p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3.5">Instructor Name</th>
                    <th className="px-4 py-3.5">Student Pool (50%)</th>
                    <th className="px-4 py-3.5">Peer Pool (20%)</th>
                    <th className="px-4 py-3.5">Head Pool (30%)</th>
                    <th className="px-4 py-3.5">Final Score (100%)</th>
                    <th className="px-4 py-3.5">Grade</th>
                    <th className="px-4 py-3.5 text-right">Report</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {instructorsScores.map((score) => (
                    <tr key={score.instructorId} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-4 py-3.5 font-bold text-slate-100">
                        <div className="text-sm">{score.instructorName}</div>
                        <div className="text-[11px] text-slate-400">{score.department}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-bold text-amber-400">{score.studentScore} / 50 pts</div>
                        <div className="text-[10px] text-slate-400">
                          Avg: {score.studentPercentage}% ({score.studentSubmissionsCount}/{score.studentTargetCount} students)
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-bold text-emerald-400">{score.peerScore} / 20 pts</div>
                        <div className="text-[10px] text-slate-400">
                          Avg: {score.peerPercentage}% ({score.peerSubmissionsCount}/{score.peerTargetCount} peers)
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-bold text-indigo-400">
                          {score.headSubmitted ? `${score.headScore} / 30 pts` : '0 / 30 pts'}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {score.headSubmitted ? `Head Rating: ${score.headPercentage}%` : 'Pending Assessment'}
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="px-3 py-1 rounded-full font-black text-sm bg-indigo-500/20 text-indigo-200 border border-indigo-500/30">
                          {score.totalFinalScore}%
                        </span>
                      </td>
                      <td className="px-4 py-3.5 font-bold text-slate-200">{score.grade}</td>
                      <td className="px-4 py-3.5 text-right">
                        <button
                          onClick={() => setSelectedReportInstId(score.instructorId)}
                          className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all inline-flex items-center gap-1"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Report Card</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Add Course Modal */}
      <Modal
        isOpen={isAddCourseModalOpen}
        onClose={() => setIsAddCourseModalOpen(false)}
        title={`Add New Course to ${dept}`}
      >
        <form onSubmit={handleAddCourseSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Course Code</label>
            <input
              type="text"
              value={newCode}
              onChange={(e) => setNewCode(e.target.value)}
              placeholder="e.g. CoSc3088"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
              required
            />
          </div>
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Course Title</label>
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="e.g. Artificial Intelligence & Machine Learning"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
              required
            />
          </div>
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Credit Hours</label>
            <input
              type="number"
              min={1}
              max={6}
              value={newCredit}
              onChange={(e) => setNewCredit(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500 font-medium"
            />
          </div>
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Assign Instructor Name (Optional)</label>
            <select
              value={newInstructorId}
              onChange={(e) => setNewInstructorId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500 font-medium cursor-pointer"
            >
              <option value="">-- Unassigned (Select Instructor) --</option>
              {departmentInstructors.map((inst) => (
                <option key={inst.id} value={inst.id}>
                  {inst.fullName} ({inst.title || 'Instructor'})
                </option>
              ))}
            </select>
          </div>
          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold shadow-lg shadow-indigo-600/30 transition-all"
          >
            Create Department Course
          </button>
        </form>
      </Modal>

      {/* Instructor 100% Performance Score Report Card Modal */}
      {selectedReportInstId && (
        <Modal
          isOpen={!!selectedReportInstId}
          onClose={() => setSelectedReportInstId(null)}
          title="MAU Official Instructor Performance Report Card"
          maxWidth="max-w-3xl"
        >
          {(() => {
            const reportScore = getInstructorFinalScore(selectedReportInstId);
            return (
              <div className="space-y-6 text-slate-100">
                {/* Formal Header */}
                <div className="text-center border-b border-slate-800 pb-4 space-y-1">
                  <div className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                    Mekdela Amba University (MAU)
                  </div>
                  <h3 className="text-lg font-black text-slate-100">
                    Academic Evaluation Performance Certificate
                  </h3>
                  <p className="text-xs text-slate-400">
                    Academic Year: {systemConfig.academicYear} • {systemConfig.semester}
                  </p>
                </div>

                {/* Instructor Info Box */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400">Instructor Name:</span>
                    <div className="font-bold text-sm text-slate-100">{reportScore.instructorName}</div>
                  </div>
                  <div>
                    <span className="text-slate-400">Department:</span>
                    <div className="font-bold text-sm text-indigo-300">{reportScore.department}</div>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-400">Assigned Courses & Credit Hours:</span>
                    <div className="font-bold text-slate-100 mt-1">
                      {departmentCourses.filter(c => c.instructorId === reportScore.instructorId).length > 0 ? (
                        <ul className="list-disc list-inside space-y-0.5">
                          {departmentCourses.filter(c => c.instructorId === reportScore.instructorId).map(c => (
                            <li key={c.id}>
                              {c.code} - {c.title} <span className="text-indigo-300">({c.creditHours} Cr.Hrs)</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <span className="text-slate-500 italic">No courses assigned</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Score Breakdown Table */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Weighted Multi-Evaluator Breakdown Formula
                  </h4>
                  <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950 text-xs">
                    <div className="p-3 border-b border-slate-800 flex justify-between items-center">
                      <div>
                        <span className="font-bold text-amber-400">1. Student Evaluation Pool (50%)</span>
                        <div className="text-[11px] text-slate-400">
                          Average student rating: {reportScore.studentPercentage}% ({reportScore.studentSubmissionsCount} of {reportScore.studentTargetCount} students submitted)
                        </div>
                      </div>
                      <span className="font-black text-amber-400 text-sm">
                        {reportScore.studentScore} / 50 pts
                      </span>
                    </div>

                    <div className="p-3 border-b border-slate-800 flex justify-between items-center">
                      <div>
                        <span className="font-bold text-emerald-400">2. Peer-to-Peer Evaluation Pool (20%)</span>
                        <div className="text-[11px] text-slate-400">
                          Average peer instructor rating: {reportScore.peerPercentage}% ({reportScore.peerSubmissionsCount} of {reportScore.peerTargetCount} peers submitted)
                        </div>
                      </div>
                      <span className="font-black text-emerald-400 text-sm">
                        {reportScore.peerScore} / 20 pts
                      </span>
                    </div>

                    <div className="p-3 flex justify-between items-center">
                      <div>
                        <span className="font-bold text-indigo-400">3. Department Head Evaluation Pool (30%)</span>
                        <div className="text-[11px] text-slate-400">
                          Official Head assessment: {reportScore.headSubmitted ? `${reportScore.headPercentage}% (Submitted)` : '0% (Pending Head Assessment)'}
                        </div>
                      </div>
                      <span className="font-black text-indigo-400 text-sm">
                        {reportScore.headScore} / 30 pts
                      </span>
                    </div>
                  </div>
                </div>

                {/* Final Score Total & Grade */}
                <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-950 via-blue-900 to-slate-900 border border-indigo-700/50 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-indigo-300 uppercase tracking-wider">
                      Final Comprehensive Evaluation Score
                    </div>
                    <div className="text-3xl font-extrabold text-white mt-1">
                      {reportScore.totalFinalScore} <span className="text-lg font-normal text-indigo-200">/ 100%</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-400">Performance Status:</div>
                    <div className="text-lg font-black text-emerald-400">{reportScore.grade}</div>
                  </div>
                </div>

                {/* Action Controls */}
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    onClick={() => handleExportToDrive(reportScore)}
                    disabled={isExporting}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-slate-900/30 active:scale-95 transition-all disabled:opacity-50"
                  >
                    {isExporting ? (
                      <span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    ) : (
                      <Sparkles className="w-4 h-4 text-emerald-400" />
                    )}
                    <span>{isExporting ? 'Exporting...' : 'Export to Google Drive'}</span>
                  </button>
                  <button
                    onClick={() => handlePrintFormalReport(reportScore)}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/30 active:scale-95 transition-transform"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print Formal Report</span>
                  </button>
                </div>
              </div>
            );
          })()}
        </Modal>
      )}

      {/* Publish Student Evaluation Form Modal */}
      {isPublishModalOpen && (
        <Modal
          isOpen={isPublishModalOpen}
          onClose={() => setIsPublishModalOpen(false)}
          title="Publish & Dispatch Student Evaluation Form"
        >
          <form onSubmit={handlePublishFormSubmit} className="space-y-4 text-xs">
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs flex items-start gap-2.5">
              <Send className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Publishing to Course Enrolled Students</span>
                <p className="text-[11px] text-amber-300/80 mt-0.5">
                  Select an instructor and assigned course to publish the official evaluation form to matching students in <strong>{dept}</strong>.
                </p>
              </div>
            </div>

            {/* Select Instructor & Assigned Course */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Select Target Instructor *</label>
                <select
                  value={pubInstructorId}
                  onChange={(e) => handleInstructorChangeForPublish(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-medium cursor-pointer"
                  required
                >
                  <option value="">-- Choose Instructor --</option>
                  {departmentInstructors.map((inst) => (
                    <option key={inst.id} value={inst.id}>
                      {inst.fullName} ({inst.title || 'Faculty'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Assigned Course *</label>
                <select
                  value={pubCourseId}
                  onChange={(e) => setPubCourseId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-medium cursor-pointer"
                  required
                >
                  <option value="">-- Select Assigned Course --</option>
                  {departmentCourses
                    .filter((c) => !pubInstructorId || c.instructorId === pubInstructorId)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.code} - {c.title} ({c.creditHours} Cr.Hrs)
                      </option>
                    ))}
                </select>
              </div>
            </div>

            {/* Target Audience Filters: Department, Year Level, Semester, Academic Year */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                <span>Target Student Criteria Filters</span>
                <span className="text-amber-400 font-normal">Matching Department: {dept}</span>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Year Level</label>
                  <select
                    value={pubYearLevel}
                    onChange={(e) => setPubYearLevel(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500"
                  >
                    <option value="All Year Levels">All Year Levels</option>
                    <option value="Year 1">Year 1</option>
                    <option value="Year 2">Year 2</option>
                    <option value="Year 3">Year 3</option>
                    <option value="Year 4">Year 4</option>
                    <option value="Year 5">Year 5</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Semester</label>
                  <select
                    value={pubSemester}
                    onChange={(e) => setPubSemester(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500"
                  >
                    <option value="Semester I">Semester I</option>
                    <option value="Semester II">Semester II</option>
                    <option value="Semester III / Summer">Semester III / Summer</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Academic Year</label>
                  <select
                    value={pubAcademicYear}
                    onChange={(e) => setPubAcademicYear(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500"
                  >
                    <option value="2025/2026">2025/2026</option>
                    <option value="2024/2025">2024/2025</option>
                  </select>
                </div>
              </div>

              {/* Matched Target Students Preview */}
              {(() => {
                const matched = departmentStudents.filter((s) => {
                  const matchYear = pubYearLevel === 'All Year Levels' || s.yearLevel === pubYearLevel;
                  return matchYear;
                });

                return (
                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <span className="text-slate-300">
                      Target Audience Matched: <strong className="text-amber-400">{matched.length > 0 ? matched.length : departmentStudents.length} Students</strong> in {dept}
                    </span>
                    <div className="flex items-center gap-1.5 overflow-x-auto max-w-xs py-1">
                      {(matched.length > 0 ? matched : departmentStudents).map((st) => (
                        <span key={st.id} className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-slate-300 font-medium whitespace-nowrap">
                          {st.fullName}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Official Evaluation Form Structure Preview */}
            <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950 p-4 space-y-3">
              <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
                <span>Official Evaluation Sheet Form Structure (1 - 5 Rating Scale)</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">50% Weight</span>
              </div>

              <div className="space-y-2 text-[11px] text-slate-300">
                <div className="p-2 rounded bg-slate-900/60 border border-slate-800/60">
                  <span className="font-bold text-amber-400">1. Core Competency (1 - 5):</span> Subject mastery, teaching methodology, clear explanations, course organization.
                </div>
                <div className="p-2 rounded bg-slate-900/60 border border-slate-800/60">
                  <span className="font-bold text-amber-400">2. Professional Competency (1 - 5):</span> Class punctuality, research integration, homework grading, accessibility.
                </div>
                <div className="p-2 rounded bg-slate-900/60 border border-slate-800/60">
                  <span className="font-bold text-amber-400">3. Ethical Competency (1 - 5):</span> Fair & unbiased grading, respectful communication, academic integrity.
                </div>
                <div className="p-2 rounded bg-slate-900/60 border border-slate-800/60">
                  <span className="font-bold text-amber-400">4. Time Management (1 - 5):</span> Syllabus coverage timeline, effective use of lecture hours.
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-sm shadow-xl shadow-amber-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <Send className="w-4 h-4 text-slate-950" />
              <span>Publish & Broadcast Evaluation Form to Selected Students</span>
            </button>
          </form>
        </Modal>
      )}

      {/* Publish Peer-to-Peer Evaluation Form Modal */}
      {isPeerPublishModalOpen && (
        <Modal
          isOpen={isPeerPublishModalOpen}
          onClose={() => setIsPeerPublishModalOpen(false)}
          title="Dispatch Peer-to-Peer Evaluation Form to Department Colleagues"
        >
          <form onSubmit={handlePeerPublishFormSubmit} className="space-y-4 text-xs">
            <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 text-xs flex items-start gap-2.5">
              <Users className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Mekdela Amba University - Instructors' Performance Evaluation Checklist</span>
                <p className="text-[11px] text-emerald-300/80 mt-0.5">
                  (To be completed by Colleagues) — Dispatch the 20-item peer checklist form to instructors in <strong>{dept}</strong> to evaluate target faculty members.
                </p>
              </div>
            </div>

            {/* Target Instructor Selection */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Target Instructor to be Evaluated *</label>
              <select
                value={peerPubTargetInstId}
                onChange={(e) => setPeerPubTargetInstId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-emerald-500 font-medium cursor-pointer"
                required
              >
                <option value="">-- Choose Target Instructor --</option>
                {departmentInstructors.map((inst) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.fullName} ({inst.title || 'Faculty Member'})
                  </option>
                ))}
              </select>
            </div>

            {/* Session Controls */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Semester</label>
                <select
                  value={peerPubSemester}
                  onChange={(e) => setPeerPubSemester(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-emerald-500"
                >
                  <option value="Semester I">Semester I</option>
                  <option value="Semester II">Semester II</option>
                  <option value="Semester III / Summer">Semester III / Summer</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Academic Year</label>
                <select
                  value={peerPubAcademicYear}
                  onChange={(e) => setPeerPubAcademicYear(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-emerald-500"
                >
                  <option value="2025/2026">2025/2026</option>
                  <option value="2024/2025">2024/2025</option>
                </select>
              </div>
            </div>

            {/* Colleague Peer Evaluators Preview */}
            {(() => {
              const colleaguePeers = departmentInstructors.filter((u) => u.id !== peerPubTargetInstId);
              return (
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center text-xs text-slate-300">
                    <span>Assigned Colleague Peer Evaluators in {dept}:</span>
                    <strong className="text-emerald-400">{colleaguePeers.length} Colleague Instructors</strong>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {colleaguePeers.map((cp) => (
                      <span key={cp.id} className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-slate-300 font-medium">
                        {cp.fullName}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })()}

            {/* 20-Item Official Peer Checklist Form Preview */}
            <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950 p-3.5 space-y-3">
              <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
                <span>Official Peer Evaluation Checklist (20 Items • 20% Score Weight)</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">Scale: 1 (VL) to 5 (VH) / NA</span>
              </div>

              <div className="space-y-2 text-[11px] text-slate-300 max-h-48 overflow-y-auto pr-1">
                <div className="p-2 rounded bg-slate-900/80 border border-slate-800/60 space-y-1">
                  <div className="font-bold text-emerald-400">Core Competency: Subject Matter (Items 1 - 4)</div>
                  <p className="text-slate-400 text-[10px]">Teaching materials preparation, subject updates, relevant seminars, subject matter knowledge & skills.</p>
                </div>
                <div className="p-2 rounded bg-slate-900/80 border border-slate-800/60 space-y-1">
                  <div className="font-bold text-emerald-400">Core Competency: Research & Community Services (Items 5 - 7)</div>
                  <p className="text-slate-400 text-[10px]">Community service engagement, workshop/seminar participation, priority research area pursuit.</p>
                </div>
                <div className="p-2 rounded bg-slate-900/80 border border-slate-800/60 space-y-1">
                  <div className="font-bold text-emerald-400">Professional Competency (Items 8 - 12)</div>
                  <p className="text-slate-400 text-[10px]">Student guidance/counseling, constructive teaching ideas, problem solving, CPD/HDP/ELIP participation, team teaching.</p>
                </div>
                <div className="p-2 rounded bg-slate-900/80 border border-slate-800/60 space-y-1">
                  <div className="font-bold text-emerald-400">Ethical Competency (Items 13 - 18)</div>
                  <p className="text-slate-400 text-[10px]">Committee commitment, resource sharing, cordiality, positive team spirit, institution rules compliance, professional discipline.</p>
                </div>
                <div className="p-2 rounded bg-slate-900/80 border border-slate-800/60 space-y-1">
                  <div className="font-bold text-emerald-400">Time Management (Items 19 - 20)</div>
                  <p className="text-slate-400 text-[10px]">Department affairs & teaching time management, office consultation hour utilization.</p>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-xl shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <Send className="w-4 h-4 text-white" />
              <span>Dispatch Peer Evaluation Form to Colleague Instructors</span>
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
};
