import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  GraduationCap,
  CheckCircle2,
  Send,
  Clock,
  BookOpen,
  ChevronRight,
  Sparkles,
  AlertCircle,
  FileCheck,
} from 'lucide-react';

interface StudentDashboardProps {
  activeTab: string;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ activeTab }) => {
  const {
    currentUser,
    users,
    courses,
    criteria,
    submissions,
    submitEvaluation,
    systemConfig,
  } = useApp();

  const dept = currentUser?.department || 'Computer Science';

  // Instructors in student's department who teach courses (fallback to all courses if none in dept)
  const matchedCourses = courses.filter((c) => c.department === dept);
  const departmentCourses = matchedCourses.length > 0 ? matchedCourses : courses;
  const studentCriteriaList = criteria.filter((c) => c.targetRole === 'student');

  // Selected instructor for evaluation form
  const [selectedInstId, setSelectedInstId] = useState<string | null>(null);
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [studentScores, setStudentScores] = useState<Record<string, number>>({});
  const [studentComment, setStudentComment] = useState('');

  const mySubmissions = submissions.filter(
    (s) => s.evaluatorId === currentUser?.id && s.evaluatorRole === 'student'
  );

  const handleStudentEvalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInstId || !currentUser) return;

    const targetInstructor = users.find((u) => u.id === selectedInstId);
    if (!targetInstructor) return;

    const targetCourse = courses.find((c) => c.id === selectedCourseId);

    const unrated = studentCriteriaList.filter((c) => studentScores[c.id] === undefined);
    if (unrated.length > 0) {
      alert(`Please select a rating for all ${studentCriteriaList.length} criteria before submitting. (${unrated.length} remaining)`);
      return;
    }

    const ratedValues = studentCriteriaList
      .map((c) => studentScores[c.id])
      .filter((v) => typeof v === 'number' && v > 0);

    const avgScore = ratedValues.length > 0
      ? ratedValues.reduce((a, b) => a + b, 0) / ratedValues.length
      : 5;
    const averagePercentage = Math.round((avgScore / 5) * 100);

    submitEvaluation({
      evaluationPeriodId: 'period_2026_sem2',
      evaluatorId: currentUser.id,
      evaluatorName: currentUser.fullName,
      evaluatorRole: 'student',
      instructorId: targetInstructor.id,
      instructorName: targetInstructor.fullName,
      courseId: targetCourse?.id,
      courseCode: targetCourse?.code,
      department: dept,
      scores: studentScores,
      averagePercentage,
      comment: studentComment,
    });

    setSelectedInstId(null);
    setSelectedCourseId(null);
    setStudentScores({});
    setStudentComment('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-950 via-yellow-900/50 to-slate-900 border border-amber-800/50 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold mb-2">
            <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
            <span>Student Portal • Mekdela Amba University</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100">{currentUser?.fullName}</h2>
          <p className="text-xs text-slate-300 mt-1">
            Department of {dept} • Active Evaluation Semester: {systemConfig.semester}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xl bg-amber-900/50 border border-amber-700/50 text-amber-200 text-xs font-bold">
            {mySubmissions.length} Evaluations Submitted
          </span>
        </div>
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-amber-400" />
                <span>My Course Instructors To Evaluate</span>
              </h3>
              <span className="text-xs text-slate-400 font-medium">
                Deadline: {new Date(systemConfig.expiryDate).toLocaleDateString()}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {departmentCourses.map((crs) => {
                const instructor = users.find((u) => u.id === crs.instructorId) || users.find((u) => u.role === 'instructor' && u.department === crs.department) || users.find((u) => u.role === 'instructor');
                if (!instructor) return null;

                const alreadySubmitted = mySubmissions.find((s) => s.instructorId === instructor.id);

                return (
                  <div key={crs.id} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                    <div className="flex justify-between items-start gap-2">
                      <div>
                        <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">{crs.code}</span>
                        <h4 className="text-sm font-bold text-slate-100">{crs.title}</h4>
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap justify-end">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          Active
                        </span>
                        {alreadySubmitted ? (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                            Submitted ({alreadySubmitted.averagePercentage}%)
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                            Pending Submission
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="text-xs text-slate-300 pt-1 border-t border-slate-800/80 flex items-center justify-between">
                      <span>Instructor: <strong>{instructor.fullName}</strong></span>
                      <span className="text-slate-400">{instructor.title}</span>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedInstId(instructor.id);
                        setSelectedCourseId(crs.id);
                        if (alreadySubmitted) {
                          setStudentScores(alreadySubmitted.scores);
                          setStudentComment(alreadySubmitted.comment || '');
                        } else {
                          setStudentScores({});
                          setStudentComment('');
                        }
                      }}
                      className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-600/20 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <span>{alreadySubmitted ? 'Edit Evaluation' : 'Evaluate Teacher Now'}</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Evaluate Teacher Form Tab */}
      {activeTab === 'evaluate_teacher' && (
        <div className="space-y-6">
          {!selectedInstId ? (
            <div className="p-8 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-3">
              <GraduationCap className="w-12 h-12 text-amber-400 mx-auto" />
              <h3 className="text-lg font-bold text-slate-100">Select a Course Instructor</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Please select an instructor from your registered department courses on the overview tab to begin evaluation.
              </p>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
                <div>
                  <div className="text-xs text-amber-400 font-bold uppercase tracking-wider">
                    Student Evaluation Form
                  </div>
                  <h3 className="text-lg font-bold text-slate-100">
                    Evaluating {users.find((u) => u.id === selectedInstId)?.fullName}
                  </h3>
                  <div className="text-xs text-slate-400 mt-1">
                    {studentCriteriaList.length} Evaluation Criteria • Weight: 50%
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const fullHigh: Record<string, number> = {};
                      studentCriteriaList.forEach((c) => {
                        fullHigh[c.id] = 5;
                      });
                      setStudentScores(fullHigh);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs font-semibold cursor-pointer transition-all"
                  >
                    Auto-Fill All Excellent (5)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedInstId(null)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>

              {/* Progress and Legend */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 flex flex-wrap items-center justify-between gap-2">
                <span className="font-bold text-amber-400">
                  Progress: {Object.keys(studentScores).length} of {studentCriteriaList.length} criteria answered
                </span>
                <div className="flex flex-wrap gap-2.5 font-mono text-[11px]">
                  <span className="text-red-400">1 = Very Low</span>
                  <span className="text-amber-400">2 = Low</span>
                  <span className="text-yellow-400">3 = Average</span>
                  <span className="text-blue-400">4 = High</span>
                  <span className="text-emerald-400">5 = Very High</span>
                </div>
              </div>

              <form onSubmit={handleStudentEvalSubmit} className="space-y-6">
                <div className="space-y-4">
                  {studentCriteriaList.map((crit, idx) => {
                    const isAnswered = studentScores[crit.id] !== undefined;
                    return (
                      <div
                        key={crit.id}
                        className={`p-4 rounded-xl border transition-all ${
                          isAnswered
                            ? 'bg-slate-950/80 border-slate-800'
                            : 'bg-amber-950/10 border-amber-500/30'
                        }`}
                      >
                        <div className="flex justify-between items-start gap-4 mb-2">
                          <span className="text-xs font-bold text-amber-300">
                            Criterion #{idx + 1} • {crit.category}
                          </span>
                          {!isAnswered && (
                            <span className="text-[10px] uppercase font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
                              Required
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-100 font-medium mb-3">{crit.questionText}</p>

                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                          {[
                            { value: 1, label: '1 - VL', color: 'text-red-400' },
                            { value: 2, label: '2 - L', color: 'text-amber-400' },
                            { value: 3, label: '3 - A', color: 'text-yellow-400' },
                            { value: 4, label: '4 - H', color: 'text-blue-400' },
                            { value: 5, label: '5 - VH', color: 'text-emerald-400' },
                            { value: 0, label: 'N/A', color: 'text-slate-400' },
                          ].map((opt) => {
                            const selected = studentScores[crit.id] === opt.value;
                            return (
                              <label
                                key={opt.value}
                                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold cursor-pointer border transition-all ${
                                  selected
                                    ? 'bg-amber-500/25 border-amber-500 text-white shadow-md shadow-amber-500/20'
                                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/60'
                                }`}
                              >
                                <input
                                  type="radio"
                                  name={`stud_crit_${crit.id}`}
                                  value={opt.value}
                                  checked={selected}
                                  onChange={() =>
                                    setStudentScores((prev) => ({ ...prev, [crit.id]: opt.value }))
                                  }
                                  className="w-4 h-4 text-amber-500 bg-slate-950 border-slate-700 focus:ring-amber-500 cursor-pointer"
                                />
                                <span className={selected ? 'text-amber-200' : opt.color}>
                                  {opt.label}
                                </span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Qualitative Feedback Comment (Optional / Anonymized)
                  </label>
                  <textarea
                    rows={3}
                    value={studentComment}
                    onChange={(e) => setStudentComment(e.target.value)}
                    placeholder="Provide constructive feedback regarding lecture delivery, lab sessions, or approachability..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Teacher Evaluation (50% Score Pool)</span>
                </button>
              </form>
            </div>
          )}
        </div>
      )}

      {/* Submissions History Tab */}
      {activeTab === 'my_submissions' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-amber-400" />
              <span>My Completed Submissions History</span>
            </h2>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Instructor Name</th>
                    <th className="px-4 py-3">Course</th>
                    <th className="px-4 py-3">Your Rating</th>
                    <th className="px-4 py-3">Feedback Comments</th>
                    <th className="px-4 py-3">Submitted At</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {mySubmissions.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-4 py-3 font-bold text-slate-100">{s.instructorName}</td>
                      <td className="px-4 py-3 font-mono text-amber-300">{s.courseCode || 'N/A'}</td>
                      <td className="px-4 py-3 font-bold text-emerald-400">{s.averagePercentage}%</td>
                      <td className="px-4 py-3 text-slate-300 italic">{s.comment || 'N/A'}</td>
                      <td className="px-4 py-3 text-slate-400 text-[11px]">
                        {new Date(s.submittedAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
