import React from 'react';
import {
  LayoutDashboard,
  UserPlus,
  Shield,
  Clock,
  History,
  BookOpen,
  Send,
  Award,
  Users,
  CheckCircle2,
  FileCheck,
  Settings,
  GraduationCap,
  Sparkles,
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarNavProps {
  role: UserRole;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarNavProps> = ({ role, activeTab, setActiveTab }) => {
  const navItemsByRole: Record<UserRole, Array<{ id: string; label: string; icon: React.ReactNode; badge?: string }>> = {
    admin: [
      { id: 'overview', label: 'Dashboard Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
      { id: 'register_users', label: 'User Registration', icon: <UserPlus className="w-4 h-4" />, badge: 'Admin' },
      { id: 'last_seen', label: 'Active & Last Seen', icon: <Clock className="w-4 h-4" /> },
      { id: 'system_config', label: 'System Configuration', icon: <Settings className="w-4 h-4" /> },
      { id: 'system_logs', label: 'System Audit Logs', icon: <History className="w-4 h-4" /> },
    ],
    head: [
      { id: 'overview', label: 'Department Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
      { id: 'assign_courses', label: 'Course Assignments', icon: <BookOpen className="w-4 h-4" /> },
      { id: 'student_eval_pool', label: 'Student Eval Pool (50%)', icon: <GraduationCap className="w-4 h-4" /> },
      { id: 'peer_eval_pool', label: 'Peer Eval Pool (20%)', icon: <Users className="w-4 h-4" /> },
      { id: 'submit_head_eval', label: 'Submit Head Eval (30%)', icon: <Send className="w-4 h-4" /> },
      { id: 'final_calculation', label: '100% Score Calculation', icon: <Award className="w-4 h-4" />, badge: 'Final' },
    ],
    instructor: [
      { id: 'overview', label: 'Instructor Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
      { id: 'assigned_courses', label: 'My Assigned Courses', icon: <BookOpen className="w-4 h-4" /> },
      { id: 'peer_eval', label: 'Peer-to-Peer Eval (20%)', icon: <Users className="w-4 h-4" /> },
      { id: 'my_performance', label: '100% Performance Score', icon: <Award className="w-4 h-4" /> },
    ],
    student: [
      { id: 'overview', label: 'Student Portal Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
      { id: 'evaluate_teacher', label: 'Evaluate Instructor (50%)', icon: <CheckCircle2 className="w-4 h-4" /> },
      { id: 'my_submissions', label: 'My Submissions', icon: <FileCheck className="w-4 h-4" /> },
    ],
  };

  const currentNavs = navItemsByRole[role] || [];

  return (
    <aside className="w-64 bg-slate-900/90 border-r border-slate-800 shrink-0 flex flex-col justify-between hidden md:flex min-h-[calc(100vh-65px)] p-4 text-slate-300">
      <div className="space-y-6">
        {/* Header Label */}
        <div className="px-3 pt-2">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>Navigation Menu</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-indigo-400 font-mono">
              {role.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Navigation List */}
        <nav className="space-y-1">
          {currentNavs.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl font-medium text-xs transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-md shadow-indigo-600/25 font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Info Widget */}
      <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>Evaluation Formula</span>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed">
          Student <strong className="text-amber-400">50%</strong> + Peer{' '}
          <strong className="text-emerald-400">20%</strong> + Head{' '}
          <strong className="text-indigo-400">30%</strong> ={' '}
          <strong className="text-slate-200">100% Comprehensive Score</strong>.
        </p>
      </div>
    </aside>
  );
};
