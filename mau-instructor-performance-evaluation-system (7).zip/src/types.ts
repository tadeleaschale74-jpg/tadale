export type UserRole = 'admin' | 'head' | 'instructor' | 'student';

export type UserStatus = 'active' | 'locked';

export interface User {
  id: string;
  username: string;
  email: string;
  password?: string;
  fullName: string;
  role: UserRole;
  college?: string;
  department: string;
  yearLevel?: string; // e.g., 'Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5', 'N/A - Faculty'
  semester?: string;  // e.g., 'Semester I', 'Semester II', 'Semester III / Summer'
  academicYear?: string; // e.g., '2025/2026'
  registrationDate?: string; // e.g., '2026-08-12'
  status: UserStatus;
  lastSeen: string;
  createdAt: string;
  avatarUrl?: string;
  title?: string; // e.g. Dr., Prof., Student, etc.
}

export const COLLEGES_AND_DEPARTMENTS: Record<string, string[]> = {
  'College of Computing & Informatics': [
    'Computer Science',
    'Information Technology',
    'Software Engineering',
    'Information Systems',
  ],
  'College of Engineering & Technology': [
    'Electrical & Computer Engineering',
    'Mechanical Engineering',
    'Civil Engineering',
    'Chemical Engineering',
    'Water Resources Engineering',
  ],
  'College of Business & Economics': [
    'Accounting & Finance',
    'Management',
    'Economics',
    'Marketing Management',
    'Logistics & Supply Chain',
  ],
  'College of Natural & Computational Sciences': [
    'Mathematics',
    'Physics',
    'Chemistry',
    'Biology',
    'Statistics',
  ],
  'College of Agriculture & Natural Resources': [
    'Plant Science',
    'Animal Science',
    'Agricultural Economics',
    'Natural Resource Management',
  ],
  'College of Social Sciences & Humanities': [
    'English Language & Literature',
    'Sociology',
    'Geography & Environmental Studies',
    'Civics & Ethical Studies',
  ],
};

export interface Course {
  id: string;
  code: string;
  title: string;
  department: string;
  creditHours: number;
  instructorId?: string | null; // Assigned instructor ID
  semester: string;
}

export interface EvaluationCriteria {
  id: string;
  category: string;
  questionText: string;
  targetRole: 'student' | 'peer' | 'head';
  maxRating: number;
}

export interface EvaluationSubmission {
  id: string;
  evaluationPeriodId: string;
  evaluatorId: string;
  evaluatorName: string;
  evaluatorRole: 'student' | 'peer' | 'head';
  instructorId: string;
  instructorName: string;
  courseId?: string;
  courseCode?: string;
  department: string;
  scores: Record<string, number>; // criteriaId -> score (1-5)
  averagePercentage: number; // 0 - 100%
  comment?: string;
  submittedAt: string;
}

export interface EvaluationPeriod {
  id: string;
  title: string;
  academicYear: string;
  semester: string;
  startDate: string;
  expiryDate: string;
  status: 'active' | 'closed' | 'upcoming';
  studentWeight: number; // e.g. 50
  peerWeight: number;    // e.g. 20
  headWeight: number;    // e.g. 30
}

export interface SystemLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  details: string;
  ipAddress?: string;
  status: 'success' | 'warning' | 'error';
}

export interface SystemConfig {
  universityName: string;
  motto: string;
  academicYear: string;
  semester: string;
  evaluationOpen: boolean;
  expiryDate: string;
  studentWeight: number; // 50
  peerWeight: number;    // 20
  headWeight: number;    // 30
  passThresholdScore: number; // e.g. 70
}

export interface PublishedForm {
  id: string;
  department: string;
  instructorId: string;
  instructorName: string;
  courseId: string;
  courseCode: string;
  courseTitle: string;
  yearLevel: string;
  semester: string;
  academicYear: string;
  targetStudentCount: number;
  publishedAt: string;
  publishedBy: string;
}

export interface PublishedPeerForm {
  id: string;
  department: string;
  targetInstructorId: string;
  targetInstructorName: string;
  semester: string;
  academicYear: string;
  targetPeerCount: number;
  publishedAt: string;
  publishedBy: string;
}

export interface InstructorFinalScore {
  instructorId: string;
  instructorName: string;
  department: string;
  studentScore: number; // Out of 50
  studentPercentage: number; // 0-100
  studentSubmissionsCount: number;
  studentTargetCount: number; // e.g. 50 students in department/course

  peerScore: number; // Out of 20
  peerPercentage: number; // 0-100
  peerSubmissionsCount: number;
  peerTargetCount: number; // e.g. colleague instructors in department

  headScore: number; // Out of 30
  headPercentage: number; // 0-100
  headSubmitted: boolean;

  totalFinalScore: number; // Out of 100
  grade: string; // e.g., Excellent, Very Good, Good, Satisfactory, Unsatisfactory
}
